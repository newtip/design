# Smart State Machine — 智能状态机（V1.1 — 6 阶段）

根据 `mode` 参数控制 Agent 间的暂停/推进策略。

## 状态转换图 (auto 模式)

```mermaid
stateDiagram-v2
    [*] --> STAGE_1_Execute : 接收需求文档
    STAGE_1_Execute --> STAGE_1_Validate : 01 Agent 完成
    STAGE_1_Validate --> STAGE_2_Execute : 格式校验通过
    STAGE_1_Validate --> STAGE_1_Retry : 校验失败
    STAGE_1_Retry --> STAGE_1_Execute : 重新执行
    
    STAGE_2_Execute --> STAGE_2_Validate : 02 Agent 完成
    STAGE_2_Validate --> STAGE_3_Execute : 自动推进
    STAGE_2_Validate --> STAGE_2_Retry : 校验失败
    
    STAGE_3_Execute --> STAGE_3_Validate : 03 Agent 完成
    STAGE_3_Validate --> STAGE_4_Execute : 自动推进
    STAGE_3_Validate --> STAGE_3_Retry : 校验失败
    
    STAGE_4_Execute --> STAGE_4_Validate : 04 Agent 完成
    STAGE_4_Validate --> STAGE_5_Execute : 自动推进
    STAGE_4_Validate --> STAGE_4_Retry : 校验失败

    STAGE_5_Execute --> STAGE_5_Validate : 05 Agent 完成
    STAGE_5_Validate --> STAGE_6_Execute : 自动推进
    STAGE_5_Validate --> STAGE_5_Retry : 校验失败
    
    STAGE_6_Execute --> STAGE_6_Checkpoint : 06 Agent 完成
    STAGE_6_Checkpoint --> Publish : 用户确认发布
    STAGE_6_Checkpoint --> STAGE_6_Edit : 用户要求修改
    STAGE_6_Edit --> STAGE_6_Execute
    
    Publish --> [*] : 飞书文档已创建
```

## 状态转换图 (review 模式)

```mermaid
stateDiagram-v2
    [*] --> STAGE_1_Execute : 接收需求文档
    STAGE_1_Execute --> STAGE_1_Review : 01 Agent 完成
    STAGE_1_Review --> STAGE_1_Edit : 用户要求修改
    STAGE_1_Edit --> STAGE_1_Execute
    STAGE_1_Review --> STAGE_2_Execute : 用户确认
    
    STAGE_2_Execute --> STAGE_2_Review : 02 Agent 完成
    STAGE_2_Review --> STAGE_2_Edit : 用户要求修改
    STAGE_2_Edit --> STAGE_2_Execute
    STAGE_2_Review --> STAGE_3_Execute : 用户确认
    
    STAGE_3_Execute --> STAGE_3_Review : 03 Agent 完成
    STAGE_3_Review --> STAGE_3_Edit : 用户要求修改
    STAGE_3_Edit --> STAGE_3_Execute
    STAGE_3_Review --> STAGE_4_Execute : 用户确认
    
    STAGE_4_Execute --> STAGE_4_Review : 04 Agent 完成
    STAGE_4_Review --> STAGE_4_Edit : 用户要求修改
    STAGE_4_Edit --> STAGE_4_Execute
    STAGE_4_Review --> STAGE_5_Execute : 用户确认

    STAGE_5_Execute --> STAGE_5_Review : 05 Agent 完成
    STAGE_5_Review --> STAGE_5_Edit : 用户要求修改
    STAGE_5_Edit --> STAGE_5_Execute
    STAGE_5_Review --> STAGE_6_Execute : 用户确认
    
    STAGE_6_Execute --> STAGE_6_Review : 06 Agent 完成
    STAGE_6_Review --> Publish : 用户确认发布
    STAGE_6_Review --> STAGE_6_Edit : 用户要求修改
    STAGE_6_Edit --> STAGE_6_Execute
    
    Publish --> [*] : 飞书文档已创建
```

## 暂停策略矩阵

| Stage | Agent | Risk | auto | review |
|:---:|------|:---:|:---:|:---:|
| 1 | 01-Req Refine | LOW | 自动 | **暂停** |
| 2 | 02-Industry Insight | MEDIUM | 自动 | **暂停** |
| 3 | 03-DDD Architecture | HIGH | 自动 | **暂停** |
| 4 | 04-Data Model | MEDIUM | 自动 | **暂停** |
| 5 | 05-Design Synthesis | MEDIUM | 自动 | **暂停** |
| 6 | 06-Solution Writer | FINAL | **暂停** | **暂停** |

## 回退规则

```yaml
rollback:
  STAGE_1:
    triggers: ["用户修改需求文档", "需求理解有误"]
    action: "清除所有后续输出（STAGE_2~6），重新从 STAGE_1 开始"

  STAGE_2:
    triggers: ["行业建议需修改", "需求成熟度重新评估"]
    action: "清除 STAGE_2~6 的输出，重新从 STAGE_2 开始"

  STAGE_3:
    triggers: ["Context 边界调整", "聚合拆分修改"]
    action: "清除 STAGE_3~6 的输出，重新从 STAGE_3 开始"

  STAGE_4:
    triggers: ["数据模型修改", "DDL 调整"]
    action: "清除 STAGE_4~6 的输出，重新从 STAGE_4 开始"

  STAGE_5:
    triggers: ["设计综合修改", "产品结构调整"]
    action: "清除 STAGE_5~6 的输出，重新从 STAGE_5 开始"

  STAGE_6:
    triggers: ["章节结构调整", "内容修改"]
    action: "重新执行 STAGE_6 Writer（不改变前序输出）"
```

## 超时处理

| 模式 | Stage | 超时 | 行为 |
|------|:---:|:---:|------|
| review | 1-5 | 15 min | 提醒用户确认，继续等待 |
| review | 1-5 | 30 min | 再次提醒，等待 |
| review | 1-5 | 60 min | 询问是否切换为 auto 模式 |
| auto | 6 only | 15 min | 保存本地 Markdown，等待用户后续发布 |
