"""STAGE_2: Industry insight — pattern matching, maturity assessment, anomaly detection."""

from typing import Any

from stages.base import LLMStage, StageResult
from memory.models import WorkflowState
from validators.industry_validator import validate_industry_output


class Stage2Industry(LLMStage):
    name = "STAGE_2_INDUSTRY_INSIGHT"
    prompt_file = "02-industry-insight.md"

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        base_ctx = super().build_context(state)
        # Add requirement output for maturity assessment
        from memory.models import Stage
        stage1_snap = state.stages.get(Stage.STAGE_1)
        if stage1_snap and stage1_snap.output:
            base_ctx['requirement_output'] = stage1_snap.output
        return base_ctx

    def run(self, context: dict[str, Any]) -> StageResult:
        prompt = self._load_prompt()
        req_output = context.get('requirement_output', {})
        response = self._call_llm(
            system_prompt=prompt,
            user_message=f"Analyze the following requirement output for industry patterns and maturity:\n\n{req_output}",
        )
        return StageResult(output={'raw_response': response})

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        output = result.output or {}
        return validate_industry_output(output)
