"""STAGE_0: Document parsing — extract full text from .docx/.md/.txt."""

import re
from typing import Any

from stages.base import BaseStage, StageResult
from memory.models import WorkflowState


class Stage0Parser(BaseStage):
    name = "STAGE_0_DOCUMENT_PARSE"

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        return {
            'input_files': state.input_files,
        }

    def run(self, context: dict[str, Any]) -> StageResult:
        files = context.get('input_files', [])
        if not files:
            return StageResult(
                needs_clarification=True,
                questions=["No input files provided. Please specify document path."],
            )

        all_text = []
        file_info = []

        for filepath in files:
            try:
                if filepath.endswith('.docx'):
                    text, stats = self._parse_docx(filepath)
                elif filepath.endswith('.md') or filepath.endswith('.txt'):
                    text, stats = self._parse_text(filepath)
                else:
                    return StageResult(
                        validation_errors=[f"Unsupported file format: {filepath}"]
                    )
                all_text.append(text)
                file_info.append(stats)
            except FileNotFoundError:
                return StageResult(
                    validation_errors=[f"File not found: {filepath}"]
                )
            except Exception as e:
                return StageResult(
                    validation_errors=[f"Error parsing {filepath}: {e}"]
                )

        # Check for truncation
        total_chars = sum(info['char_count'] for info in file_info)
        truncation_warning = (
            "⚠️ Warning: Document may be truncated (>100K chars). "
            "Please verify completeness."
            if total_chars > 100000 else ""
        )

        return StageResult(
            output={
                'full_text': '\n\n'.join(all_text),
                'file_info': file_info,
                'total_chars': total_chars,
                'truncation_warning': truncation_warning,
            },
            warnings=[truncation_warning] if truncation_warning else [],
        )

    def _parse_docx(self, filepath: str) -> tuple[str, dict]:
        from docx import Document
        doc = Document(filepath)
        paragraphs = []
        table_count = 0
        for para in doc.paragraphs:
            paragraphs.append(para.text)
        for _ in doc.tables:
            table_count += 1
        text = '\n'.join(paragraphs)
        stats = {
            'file': filepath,
            'paragraphs': len(paragraphs),
            'tables': table_count,
            'char_count': len(text),
        }
        return text, stats

    def _parse_text(self, filepath: str) -> tuple[str, dict]:
        with open(filepath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        stats = {
            'file': filepath,
            'lines': len(lines),
            'char_count': len(text),
        }
        return text, stats

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        errors = []
        if not result.output:
            errors.append("No output from document parser")
            return errors

        text = result.output.get('full_text', '')
        if not text or len(text.strip()) < 100:
            errors.append("Document appears empty or too short (<100 chars)")

        return errors
