"""Abstract base class for all workflow stages."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from memory.models import WorkflowState


@dataclass
class StageResult:
    output: dict[str, Any] = field(default_factory=dict)
    needs_clarification: bool = False
    questions: list[str] = field(default_factory=list)
    validation_errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class BaseStage(ABC):
    """Every stage must define: build_context -> run -> validate."""

    name: str

    @abstractmethod
    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        """Extract minimal context needed for this stage from global state."""
        ...

    @abstractmethod
    def run(self, context: dict[str, Any]) -> StageResult:
        """Execute the stage. Calls LLM or local tools, returns structured result."""
        ...

    @abstractmethod
    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        """Quality gate. Return list of validation error messages (empty = pass)."""
        ...


class LLMStage(BaseStage):
    """Stage that delegates generation to an LLM via a prompt template."""

    prompt_file: str  # Path to the .md prompt template
    output_schema: dict | None = None

    def _load_prompt(self) -> str:
        """Load the prompt template."""
        from pathlib import Path
        engine_dir = Path(__file__).parent.parent
        prompt_path = engine_dir / 'prompts' / self.prompt_file
        if prompt_path.exists():
            return prompt_path.read_text(encoding='utf-8')
        return f"# {self.name}\n\nNo prompt template found at {prompt_path}"

    def _call_llm(self, system_prompt: str, user_message: str) -> str:
        """Call the LLM. Override this or configure via tools/llm.py."""
        try:
            from tools.llm import call_llm
            return call_llm(system_prompt, user_message)
        except ImportError:
            raise NotImplementedError(
                "LLM calling not configured. Set up tools/llm.py or override _call_llm."
            )

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        """Default: collect all upstream stage outputs."""
        from workflow.graph import WorkflowGraph
        graph = WorkflowGraph()
        upstream = graph.upstream(self.name)
        context = {
            'global_facts': state.global_facts,
            'ubiquitous_language': state.ubiquitous_language,
            'assumptions': state.assumptions,
            'open_questions': state.open_questions,
            'upstream_outputs': {
                s.value: state.stages[s].output
                for s in upstream
                if state.stages[s].output
            },
        }
        return context

    def run(self, context: dict[str, Any]) -> StageResult:
        """Default: load prompt, call LLM, parse result."""
        prompt = self._load_prompt()
        user_message = f"Context:\n{context}\n\nComplete the stage as described in the prompt."
        response = self._call_llm(prompt, user_message)
        return StageResult(output={"raw_response": response})
