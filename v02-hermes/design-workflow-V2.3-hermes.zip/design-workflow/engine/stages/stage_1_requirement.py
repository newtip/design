"""STAGE_1: Requirement refinement — extract business model from document text."""

from typing import Any

from stages.base import LLMStage, StageResult
from memory.models import WorkflowState
from validators.requirement_validator import validate_requirement_output


class Stage1Requirement(LLMStage):
    name = "STAGE_1_REQUIREMENT_REFINEMENT"
    prompt_file = "01-requirement-refinement.md"

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        base_ctx = super().build_context(state)
        # Add parsed document text
        doc_output = state.stages[state.stages.__class__.__annotations__] if False else {}
        if state.stages and hasattr(state, 'stages'):
            from memory.models import Stage
            stage0_snap = state.stages.get(Stage.STAGE_0)
            if stage0_snap and stage0_snap.output:
                base_ctx['document_text'] = stage0_snap.output.get('full_text', '')
        return base_ctx

    def run(self, context: dict[str, Any]) -> StageResult:
        # In a real implementation, this calls the LLM.
        # For now, provide a structured call pattern.
        prompt = self._load_prompt()
        doc_text = context.get('document_text', '')

        response = self._call_llm(
            system_prompt=prompt,
            user_message=f"Parse the following requirement document and extract business model:\n\n{doc_text[:50000]}",
        )

        return StageResult(
            output={
                'raw_response': response,
                'document_snippet': doc_text[:500],
            },
            warnings=["LLM response not yet parsed into structured schema. See validation errors."],
        )

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        output = result.output or {}
        return validate_requirement_output(output)
