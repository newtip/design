"""STAGE_6: Solution writer — produce AE 9-chapter design document."""

from typing import Any

from stages.base import LLMStage, StageResult
from memory.models import WorkflowState
from validators.final_doc_validator import validate_final_output


class Stage6Writer(LLMStage):
    name = "STAGE_6_SOLUTION_WRITER"
    prompt_file = "06-solution-writer.md"

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        base_ctx = super().build_context(state)
        from memory.models import Stage
        for s in (Stage.STAGE_1, Stage.STAGE_3, Stage.STAGE_4, Stage.STAGE_5):
            snap = state.stages.get(s)
            if snap and snap.output:
                base_ctx[s.value] = snap.output
        base_ctx['open_questions'] = state.open_questions
        base_ctx['assumptions'] = state.assumptions
        return base_ctx

    def run(self, context: dict[str, Any]) -> StageResult:
        prompt = self._load_prompt()
        response = self._call_llm(
            system_prompt=prompt,
            user_message=f"Write the 9-chapter design document based on:\n\n{context}",
        )
        return StageResult(output={
            'raw_response': response,
            'chapters': {f'chapter_{i}': '' for i in range(1, 10)},
        })

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        output = result.output or {}
        return validate_final_output(output, state)
