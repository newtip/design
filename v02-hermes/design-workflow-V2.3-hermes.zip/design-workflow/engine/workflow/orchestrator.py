"""Non-linear orchestrator: state-driven, dependency-aware execution."""

from typing import Any

from workflow.graph import WorkflowGraph
from workflow.state_machine import StageStatus, is_blocking
from memory.models import WorkflowState, Stage, StageSnapshot
from stages.base import BaseStage, StageResult


class Orchestrator:
    def __init__(self, graph: WorkflowGraph, stages: dict[Stage, BaseStage]):
        self.graph = graph
        self.stages = stages

    def refresh_ready_stages(self, state: WorkflowState) -> None:
        """Set any pending stage to READY if all upstream deps are COMPLETED."""
        completed = {
            s.stage for s in state.stages.values()
            if s.status == StageStatus.COMPLETED
        }
        for stage, snapshot in state.stages.items():
            if snapshot.status != StageStatus.PENDING:
                continue
            if self.graph.is_ready(stage, completed):
                snapshot.status = StageStatus.READY

    def choose_next_stage(self, state: WorkflowState) -> Stage | None:
        """Pick the highest-priority READY stage."""
        self.refresh_ready_stages(state)
        for stage in self.graph.priority_order:
            snap = state.stages[stage]
            if snap.status == StageStatus.READY:
                return stage
        return None

    def run_once(self, state: WorkflowState) -> WorkflowState:
        """Execute one tick: pick the next READY stage and run it."""
        stage = self.choose_next_stage(state)
        if stage is None:
            return state  # No work to do

        state.current_stage = stage
        snapshot = state.stages[stage]
        snapshot.status = StageStatus.RUNNING

        # Execute
        stage_impl = self.stages[stage]
        try:
            context = stage_impl.build_context(state)
            result = stage_impl.run(context)
        except Exception as e:
            snapshot.status = StageStatus.VALIDATION_FAILED
            snapshot.validation_errors = [f"Execution error: {e}"]
            return state

        # Validate
        try:
            validation_errors = stage_impl.validate(result, state)
        except Exception as e:
            validation_errors = [f"Validation error: {e}"]
        validation_errors.extend(result.validation_errors)

        # Handle result
        if result.needs_clarification:
            snapshot.status = StageStatus.NEEDS_CLARIFICATION
            snapshot.clarification_questions = result.questions
            state.open_questions.extend(result.questions)
            return state

        if validation_errors:
            snapshot.status = StageStatus.VALIDATION_FAILED
            snapshot.validation_errors = validation_errors
            return state

        # Success
        snapshot.output = result.output
        snapshot.warnings = result.warnings
        snapshot.version += 1
        snapshot.status = StageStatus.COMPLETED
        return state

    def apply_change(
        self,
        state: WorkflowState,
        changed_stage: Stage,
        patch: dict[str, Any],
    ) -> WorkflowState:
        """Update a stage and recursively invalidate downstream stages."""
        snapshot = state.stages[changed_stage]
        snapshot.output = {**(snapshot.output or {}), **patch}
        snapshot.version += 1
        snapshot.status = StageStatus.COMPLETED

        impacted = self.graph.impacted_by_change(changed_stage)
        for s in impacted:
            state.stages[s].status = StageStatus.INVALIDATED
            state.stages[s].validation_errors = [
                f"Upstream stage {changed_stage.value} changed (v{snapshot.version})."
            ]
        return state

    def run_until_blocked(self, state: WorkflowState) -> WorkflowState:
        """Keep running stages until no more ready or something blocks."""
        max_ticks = 10
        for _ in range(max_ticks):
            previous = state.model_dump_json()
            state = self.run_once(state)
            if state.model_dump_json() == previous:
                break
            # Check for blocking conditions
            for snap in state.stages.values():
                if is_blocking(snap.status):
                    return state
        return state

    def get_progress(self, state: WorkflowState) -> dict[str, Any]:
        """Return a status summary for display."""
        return {
            stage.value: {
                "status": snap.status.value,
                "errors": snap.validation_errors,
                "warnings": snap.warnings,
                "questions": snap.clarification_questions,
            }
            for stage, snap in state.stages.items()
        }
