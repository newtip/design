"""LLM calling adapter. Configure to use your LLM backend."""

import os
import json


def call_llm(system_prompt: str, user_message: str, model: str | None = None) -> str:
    """Call the LLM and return the response text.

    Configure via environment variables:
      LLM_PROVIDER: 'openai' | 'anthropic' | 'hermes' (default: hermes)
      LLM_MODEL: model name
      OPENAI_API_KEY / ANTHROPIC_API_KEY: credentials
    """
    provider = os.getenv('LLM_PROVIDER', 'hermes')
    model_name = model or os.getenv('LLM_MODEL', 'deepseek-v4-pro')

    if provider == 'hermes':
        return _call_hermes(system_prompt, user_message, model_name)
    elif provider == 'openai':
        return _call_openai(system_prompt, user_message, model_name)
    elif provider == 'anthropic':
        return _call_anthropic(system_prompt, user_message, model_name)
    else:
        raise NotImplementedError(f"Unknown LLM provider: {provider}")


def _call_hermes(system_prompt: str, user_message: str, model: str) -> str:
    """Call Hermes CLI. Writes result to a temp file and reads back."""
    import tempfile
    import subprocess

    # Write prompts to temp files
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
        f.write(f"System: {system_prompt}\n\nUser: {user_message}")
        prompt_file = f.name

    try:
        result = subprocess.run(
            [
                'hermes', 'chat', '-q',
                f'Complete the task described in the prompt file at {prompt_file}. '
                'Output structured JSON or markdown as appropriate.',
                '-m', model,
                '-Q', '--yolo',
                '--source', 'dwe',
            ],
            capture_output=True, text=True, timeout=300,
        )
        return result.stdout.strip() or result.stderr.strip()
    finally:
        os.unlink(prompt_file)


def _call_openai(system_prompt: str, user_message: str, model: str) -> str:
    import urllib.request, urllib.error

    api_key = os.getenv('OPENAI_API_KEY', '')
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set")

    data = json.dumps({
        'model': model,
        'messages': [
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': user_message},
        ],
    }).encode()

    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions',
        data=data,
        headers={
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}',
        },
    )

    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read())
        return result['choices'][0]['message']['content']


def _call_anthropic(system_prompt: str, user_message: str, model: str) -> str:
    import urllib.request, urllib.error

    api_key = os.getenv('ANTHROPIC_API_KEY', '')
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not set")

    data = json.dumps({
        'model': model,
        'max_tokens': 4096,
        'system': system_prompt,
        'messages': [{'role': 'user', 'content': user_message}],
    }).encode()

    req = urllib.request.Request(
        'https://api.anthropic.com/v1/messages',
        data=data,
        headers={
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01',
        },
    )

    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read())
        return result['content'][0]['text']


# Stub implementations for optional tools
def call_llm_structured(system_prompt: str, user_message: str, output_schema: dict) -> dict:
    """Call LLM and parse structured output according to schema."""
    response = call_llm(system_prompt, user_message)
    # Try to extract JSON from response
    try:
        # Find JSON block
        import re
        json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
        if json_match:
            return json.loads(json_match.group(1))
        json_match = re.search(r'\{[\s\S]*\}', response)
        if json_match:
            return json.loads(json_match.group(0))
    except json.JSONDecodeError:
        pass
    return {'raw_response': response, 'parse_error': 'Could not extract JSON'}
