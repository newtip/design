"""Quality gate for STAGE_6 final document output."""

from memory.models import WorkflowState


REQUIRED_CHAPTERS = list(range(1, 10))  # Chapters 1-9
CHAPTER_MIN_LENGTH = {
    1: 500,   # Feature list
    2: 800,   # Architecture
    3: 800,   # Business processes
    4: 1000,  # Data model
    5: 800,   # Function design
    6: 400,   # Permissions
    7: 600,   # Non-functional
    8: 200,   # Open issues
    9: 300,   # Effort estimation
}


def validate_final_output(output: dict, state: WorkflowState) -> list[str]:
    """Validate the final 9-chapter document for completeness."""
    errors = []

    chapters = output.get('chapters', {})
    doc_text = output.get('raw_response', '')

    # Check all chapters present
    for ch in REQUIRED_CHAPTERS:
        ch_key = f'chapter_{ch}'
        content = chapters.get(ch_key, '')
        min_len = CHAPTER_MIN_LENGTH.get(ch, 0)

        if not content and ch_key not in chapters:
            errors.append(f"Missing chapter {ch}")

        if isinstance(content, str) and len(content) < min_len:
            errors.append(
                f"Chapter {ch} too short ({len(content)} chars, min {min_len}). "
                f"May be incomplete."
            )

    # Check appendices
    if 'appendix_a_events' not in output:
        errors.append("Missing Appendix A: Event inventory")
    if 'appendix_b_generation_log' not in output:
        errors.append("Missing Appendix B: Generation log")

    # Check DDL is separate
    if 'ddl_file' not in output and not any(
        'CREATE TABLE' in ch.get(ch_key, '') for ch_key in chapters
    ):
        errors.append("No DDL statements found. Should include CREATE TABLE in Chapter 4 or as separate file.")

    # Check no made-up content
    assumptions = state.assumptions
    if doc_text and 'will support' in doc_text.lower():
        # Flag potential fabricated features
        pass

    # Check all open_questions are in Chapter 8
    if state.open_questions and 'chapter_8' in chapters:
        ch8 = chapters['chapter_8']
        for q in state.open_questions:
            if q not in ch8:
                errors.append(f"Open question not in Chapter 8: {q[:80]}...")

    return errors
