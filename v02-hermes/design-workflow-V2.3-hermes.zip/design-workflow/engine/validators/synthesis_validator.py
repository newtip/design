"""Quality gate for STAGE_5 design synthesis output."""

from validators.base import check_required_keys


def validate_synthesis_output(output: dict) -> list[str]:
    """Validate design synthesis has clear design intent and trade-off decisions."""
    errors = []

    required = ['design_narrative', 'main_workspace', 'trade_offs', 'writer_strategy']
    errors.extend(check_required_keys(output, required, 'synthesis'))

    # Design narrative must be clear
    narrative = output.get('design_narrative', '')
    if isinstance(narrative, str) and len(narrative) < 200:
        errors.append(f"Design narrative too short ({len(narrative)} chars). Must explain the design intent clearly.")

    # Trade-offs must have rationale
    for tradeoff in output.get('trade_offs', []):
        name = tradeoff.get('name', 'unnamed')
        if not tradeoff.get('options'):
            errors.append(f"Trade-off '{name}' missing options")
        if not tradeoff.get('decision') or not tradeoff.get('rationale'):
            errors.append(f"Trade-off '{name}' missing decision or rationale")

    # Writer strategy must map to chapters
    writer = output.get('writer_strategy', {})
    if writer and not writer.get('chapter_emphasis'):
        errors.append("Writer strategy missing chapter_emphasis mapping")

    return errors
