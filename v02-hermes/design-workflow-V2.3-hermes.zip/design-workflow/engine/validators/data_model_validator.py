"""Quality gate for STAGE_4 data model output."""

from validators.base import check_required_keys


# Enterprise standard fields that every DDL table must include
STANDARD_FIELDS = {
    'data_id', 'create_member', 'create_time', 'create_member_ip_address',
    'last_mod_member', 'last_mod_time', 'last_mod_member_ip_address',
    'del_flag', 'source_system',
}

# Field semantics that should NOT be persisted as columns
NON_PERSISTABLE_SEMANTICS = {'projection_field', 'derived_field'}


def validate_data_model_output(output: dict) -> list[str]:
    """Validate data model output: standard fields, entity ownership, non-persistable fields."""
    errors = []

    required = ['entities', 'er_relationships', 'ddl_statements']
    errors.extend(check_required_keys(output, required, 'data_model'))

    # Check each table/entity
    entities = output.get('entities', [])
    tables = output.get('tables', entities)  # Support both naming conventions

    for table in tables:
        table_name = table.get('name', 'unnamed')
        fields = table.get('fields', [])

        # Check standard fields
        field_names = {f.get('name', '') for f in fields}
        missing_std = STANDARD_FIELDS - field_names
        if missing_std:
            errors.append(
                f"Table '{table_name}' missing standard fields: {sorted(missing_std)}"
            )

        # Check for non-persistable fields
        for field in fields:
            field_name = field.get('name', 'unnamed')
            semantic = field.get('semantic', '')
            if semantic in NON_PERSISTABLE_SEMANTICS:
                errors.append(
                    f"Table '{table_name}' field '{field_name}' has semantic '{semantic}' "
                    f"— should not be persisted as a column (use JOIN instead)"
                )

        # Check table naming reflects context
        if not table_name.startswith(('tc_', 'enr_', 'usr_', 'sys_', 'ord_', 'prj_')):
            errors.append(
                f"Table '{table_name}' does not follow context prefix convention "
                f"(e.g., tc_ for TrainingClass, enr_ for Enrollment)"
            )

    # Check ER relationships reference existing entities
    entity_names = {t.get('name', '') for t in tables}
    for rel in output.get('er_relationships', []):
        src = rel.get('source_entity', '')
        tgt = rel.get('target_entity', '')
        if src not in entity_names:
            errors.append(f"ER relationship references non-existent entity: '{src}'")
        if tgt not in entity_names:
            errors.append(f"ER relationship references non-existent entity: '{tgt}'")

    return errors
