"""Quality gate for STAGE_2 industry insight output."""

from validators.base import check_required_keys


def validate_industry_output(output: dict) -> list[str]:
    """Validate industry insight output has maturity score and actionable items."""
    errors = []

    required = ['industry_patterns', 'maturity_assessment', 'decision_todos', 'anomaly_scenarios']
    errors.extend(check_required_keys(output, required, 'industry'))

    # Check maturity assessment
    maturity = output.get('maturity_assessment', {})
    if maturity:
        score = maturity.get('score', 0)
        if not isinstance(score, (int, float)) or not (0 <= score <= 100):
            errors.append(f"Maturity score must be 0-100, got: {score}")
        if score < 50:
            # This triggers the maturity gate in the orchestrator
            errors.append(
                f"⚠️ Maturity score {score} < 50. "
                "Design may contain significant assumptions. Consider pausing for user review."
            )

    # Check decision todos are actionable
    for todo in output.get('decision_todos', []):
        if not todo.get('action') or not todo.get('owner'):
            errors.append(f"Decision todo missing action/owner: {todo.get('title', 'unnamed')}")

    return errors
