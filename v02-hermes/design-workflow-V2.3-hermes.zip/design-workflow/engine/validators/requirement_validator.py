"""Quality gate for STAGE_1 requirement output."""

from validators.base import check_required_keys, check_source_anchors


def validate_requirement_output(output: dict) -> list[str]:
    """Validate that requirement refinement output is complete and traceable."""
    errors = []

    # Check required top-level keys
    required = [
        'business_goals', 'actors', 'business_objects',
        'commands', 'events', 'business_rules',
        'fields', 'open_questions',
    ]
    errors.extend(check_required_keys(output, required, 'requirement'))

    # Check business goals have measurable outcomes
    for goal in output.get('business_goals', []):
        name = goal.get('name', 'unnamed')
        if not goal.get('measurable_outcome'):
            errors.append(f"Business goal '{name}' missing measurable_outcome")

    # Check actors
    for actor in output.get('actors', []):
        name = actor.get('name', 'unnamed')
        if not actor.get('role_type'):
            errors.append(f"Actor '{name}' missing role_type")

    # Check commands have source_anchor
    errors.extend(check_source_anchors(
        output.get('commands', []), 'Command'
    ))

    # Check business rules have source_anchor
    errors.extend(check_source_anchors(
        output.get('business_rules', []), 'Business rule'
    ))

    # Check events follow granularity rules
    events = output.get('events', [])
    event_names = {e.get('name', '') for e in events}
    for e in events:
        name = e.get('name', '')
        # Check for missing re-submit event if there's a reject event
        if 'Reject' in name or '退回' in name:
            resubmit_name = name.replace('Reject', 'ReSubmit').replace('退回', '重新提交')
            if resubmit_name not in event_names:
                errors.append(
                    f"Event granularity: '{name}' should have a corresponding re-submit event "
                    f"(e.g., '{resubmit_name}')"
                )

    return errors
