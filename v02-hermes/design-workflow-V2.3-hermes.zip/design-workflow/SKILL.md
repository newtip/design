---
name: design-workflow
description: DDD+AE 融合概要设计 Skill。单 Agent 顺序执行 7 阶段工作流，输出 AE 标准 9 章概设。支持 auto（自动推进）和 review（逐步确认）双模式。
---

# Design Workflow — DDD + AE 融合概设引擎 V2.3

## 定位

融合 ddd-solution 的事件驱动建模与 ae-design 的 9 章概设交付。
**V2.3 在单 Agent 顺序执行基础上加入 Harness Engineering（驾驭工程）优化层**：用目标契约、上下文约束、状态机、工具降级、质量门禁来驾驭模型执行，不再只依赖长 Prompt。

## 两种模式

**默认 auto，不要问用户选模式。** 用户说"概设"、"跑 design-workflow"即直接 auto 推进。仅当用户明确说"review 模式"时才用 review。

| 模式 | 行为 |
|------|------|
| **auto** | 全程自动推进，仅在最后交付前用 `clarify` 确认 |
| **review** | 每个阶段完成后用 `clarify` 展示结果，等待用户确认/补充 |

### auto 模式效率铁律

- **每阶段输出压缩到关键结论**，不要逐条展开长篇推理。优先表格而非段落。
- STAGE_1~5 的中间输出是给机器看的，不是给用户看的——只保留决策点和例外标注。
- 严禁在 auto 模式下输出完整 schema YAML、逐条 reasoning、或逐字段解释。
- 目标：STAGE_0~6 全部跑完，用户看到的是 STAGE_6 的 9 章文档，不是中间产物。
- **反模式**：STAGE_3 输出完整 DDD 架构时，不要逐表展开 domains/contexts/aggregates/services/communication 五张详细表格外加架构图。一张 Context+服务汇总表 + 一个聚合列表 + 一句话架构模式结论就够了。详细内容留给 STAGE_6。

---

## 驾驭工程优化层

本 Skill 采用 Harness Engineering 思路：**人类掌舵，Agent 执行；模型负责生成，Harness 负责约束、状态、校验、回退和交付**。执行前必须加载：

- `harness/HARNESS_ENGINEERING.md`：目标、状态、门禁、回退、验收标准
- `harness/TOOL_FALLBACKS.md`：工具缺失、外部服务、安全降级策略

### 五层 Harness

| 层 | 作用 | 强制要求 |
|---|---|---|
| Goal Harness | 目标与验收 | 明确产出 AE 9 章 + 附录 + 风险清单 |
| Context Harness | 事实来源 | 需求事实必须有 source_anchor |
| Process Harness | 阶段推进 | STAGE_0~6 都有准入/准出门禁 |
| Tool Harness | 工具边界 | 工具缺失必须降级，外部服务默认关闭 |
| Quality Harness | 校验闭环 | Schema、traceability、成熟度、最终验收 |

## 执行流程（7 阶段）

优先用 `todo` 工具跟踪进度；如果环境没有 `todo`，用 Markdown checklist 记录。每完成一个阶段必须更新 `architecture_memory.stage_checkpoints`。

### STAGE_0：文档解析

**目标**：完整提取需求文档，检测截断。

- 读取用户提供的文档文件（支持 .docx / .md / .txt）
- 对于 .docx：用 `terminal` 运行 `python-docx` 提取段落和表格
- 统计段落数、表格数，检查完整性
- 输出：全文 Markdown + 完整性报告
- 参考：`agents/00-document-parser.md`
- **此阶段不暂停**

### STAGE_1：需求提炼

**目标**：从文档提取业务目标、Actor、事件流、能力、痛点。

- 详细参考：`agents/01-requirement-refinement.md`
- 输出 Schema：`schemas/requirement.schema.yaml`
- 输出：`business_model`（业务目标、角色、事件风暴、能力图、痛点、开放问题）
- **review 模式**：展示摘要，clarify 等待确认

### STAGE_2：行业经验增强

**目标**：行业模式匹配、异常边界识别、需求成熟度评估。

- 详细参考：`agents/02-industry-insight.md`
- 输出 Schema：`schemas/industry-insight.schema.yaml`
- 输出：`industry_insight`（行业模式、成熟度评分、决策待办、异常流程）
- **⛔ 成熟度 < 50 时**：auto 模式暂停警告，review 模式标注"以假设为主"

### STAGE_3：DDD 架构设计

**目标**：领域划分、限界上下文、聚合、服务、架构。

- 详细参考：`agents/03-ddd-architecture.md`
- 输出 Schema：`schemas/architecture.schema.yaml`
- 输出：`architecture_design`（Context 划分、聚合根、服务、通信模式）
- 填写 `architecture_memory`（已确认决策记录）

### STAGE_4：数据模型设计

**目标**：实体归属、ER 关系、字段语义分类、DDL。

- 详细参考：`agents/04-data-model.md`
- 输出 Schema：`schemas/data-model.schema.yaml`
- 输出：`data_model`（实体定义、ER 关系、DDL、投影字段标注不建列）

### STAGE_5：设计综合

**目标**：设计意图识别、产品结构、体验策略、设计取舍。

- 详细参考：`agents/05-design-synthesis.md`
- 输出 Schema：`schemas/design-synthesis.schema.yaml`
- 输出：`design_synthesis`（设计主线、主工作台、取舍、Writer 表达策略）

### STAGE_6：概设输出

**目标**：按 AE 9 章结构撰写，交付到飞书。

- 详细参考：`agents/06-solution-writer.md`
- 输出模板：`templates/overview_structure.yaml`
- 按 3 个 Phase 分批生成（第1-3章 → 第4-6章 → 第7-9章）
- 生成后保存到本地 `.md` 文件
- 发布前必须等待用户确认
- 优先输出本地 `.md`、`.sql`、`.mmd` 文件；如有飞书工具且用户确认，再发布飞书
- 外部 Mermaid 渲染默认关闭，除非用户明确允许

---

## 9 章输出结构

| 章 | 内容 | 数据来源 |
|:---:|------|---------|
| 1 | 功能清单 | STAGE_1 + STAGE_2 + STAGE_5 |
| 2 | 系统架构设计 | STAGE_3 + STAGE_5 |
| 3 | 业务流程设计 | STAGE_1 + STAGE_2 + STAGE_3 + STAGE_5 |
| 4 | 数据模型设计 | STAGE_4 |
| 5 | 功能设计 | STAGE_1 + STAGE_3 + STAGE_5 |
| 6 | 权限设计 | STAGE_3 |
| 7 | 非功能设计 | STAGE_2 + STAGE_3 |
| 8 | 遗留问题 | 全部 open_questions + 决策待办 |
| 9 | 工作量评估 | 按 Context 拆分 + 分阶段开发顺序 + 缓冲 |

---

## 关键规则

1. **成熟度门控**：STAGE_2 评估 < 50 时 auto 模式强制暂停
2. **行业建议标注**：
   - ✅ 已确认 | ⚠️ 建议 | 🔶 假设/待审查 | ❓ 待确认（放第8章）
3. **投影字段不建列**：DDL 中标注"通过 JOIN 获取"
4. **术语统一**：全程使用 ubiquitous_language 统一术语
5. **不捏造**：不生成需求文档中不存在的内容
6. **飞书文档权限**：需要飞书开放平台开通 `docx:document:create`、`docx:document:write_only` 权限才能创建文档
7. **飞书群聊交付**：通过 MEDIA 文件附件 + 同时贴全文到消息中。飞书群聊中 bot 间消息互不可见（除非 @mention），如需其他 bot 阅读输出，必须 @mention 对方或贴全文到消息中
8. **禁止追问模式**：用户说"概设"/"跑 design-workflow"即直接 auto 执行，不要再问"用哪种模式"。用户说"用最新 skill 去进行概设" = 直接跑，不需要确认。

## 操作提示

- **续跑模式**：当用户已自行完成部分阶段输出（如共享了部分 STAGE_1 的 Business Model / Actors），直接从上一次中断处继续，跳过已完成部分。使用 session_search 查找前置输出，用 search_files 定位已保存的中间文件。
- **STAGE_5 合并优化**：auto 模式下 STAGE_5（设计综合）可直接合并入 STAGE_6（概设输出）——STAGE_5 的设计意图/取舍/表达策略作为第 9 章概设的前导说明写入，不单独输出 yaml。
- **YAML 大文件注意**：STAGE_1/3/4 输出 YAML 文件可达 40-80KB，字符串字段中引号不匹配会导致 `YAMLError`。写完文件后检查 lint 结果，出错时用 patch 工具修正具体行。

---

## 资源文件

| 目录 | 说明 |
|------|------|
| `agents/` | 7 个阶段详细 Agent prompt（参考阅读，不是子 agent） |
| `schemas/` | 各阶段输出 Schema（YAML） |
| `templates/` | 概设 9 章结构模板 |
| `scripts/` | 飞书发布 + Mermaid 渲染辅助脚本 |
| `harness/` | 五层驾驭工程约束 |
| `orchestrator/` | 状态机、架构记忆、编排器 |
| `engine/` | **Python 工程化编排引擎**（DAG + 状态机 + 编排器 + 校验器 + CLI） |

### Python 引擎 (`engine/`)

V2.3 附带一个完整的 Python 工程化引擎，实现非线性执行：

```bash
cd ~/.hermes/skills/design-workflow/engine

# 启动新 run
python -m app.main start --input docs/需求.docx

# 查看状态
python -m app.main status --run-id 20260601_143000

# 断点续跑
python -m app.main resume --run-id 20260601_143000

# 修改需求后重跑受影响阶段
python -m app.main rerun --run-id 20260601_143000 --stage STAGE_1

# 导出最终文档
python -m app.main export --run-id 20260601_143000
```

引擎核心能力：DAG 依赖图（`impacted_by_change` 自动计算失效范围）、状态机（8 种状态生命周期）、质量门禁（每阶段独立校验）、失败路由（知道回退到哪个上游修复点）、JSON 持久化（断点续跑）。

引擎的 `prompts/` 和 `schemas/` 通过符号链接复用 `agents/` 和 `schemas/` 目录。

---

## 变更日志

### V2.3 (2026-06-01) — Harness Engineering 优化
- ✅ STAGE_4 新增企业级 9 标准字段规范
- ✅ STAGE_3 新增 DDD 边界铁律
- ✅ STAGE_1 新增事件粒度要求
- ✅ STAGE_6 新增附录 A 事件清单 + 附录 B 生成记录
- ✅ 第7章新增缓存策略/安全细节/审计方案 checklist
- ✅ 新增 harness 五层驾驭结构 + tool fallbacks
- ✅ 统一 7 阶段状态机
- ✅ Mermaid 外部渲染改为显式 opt-in
