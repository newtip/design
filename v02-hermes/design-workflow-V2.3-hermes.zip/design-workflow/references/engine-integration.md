# Engine Integration Notes

The `design-workflow` skill includes a Python engineering engine at `engine/` that provides nonlinear workflow execution.

## Architecture

```
engine/
├── app/main.py            # CLI (start/status/resume/rerun/export)
├── app/config.py          # EngineConfig from env or YAML
├── workflow/
│   ├── graph.py           # DAG dependencies + impacted_by_change()
│   ├── state_machine.py   # 8 status states + transition matrix
│   ├── orchestrator.py    # Non-linear executor (not stage+=1)
│   └── router.py          # Failure routing (knows which upstream to fix)
├── stages/
│   ├── base.py            # BaseStage + LLMStage abstract
│   └── stage_0_parser.py ~ stage_6_writer.py
├── memory/
│   ├── models.py          # Pydantic: Stage, StageStatus, WorkflowState
│   └── store.py           # JSON persistence to outputs/runs/{run_id}/
├── validators/            # Per-stage quality gates
│   ├── requirement_validator.py  # source_anchor, event granularity
│   ├── architecture_validator.py  # cross-cutting concern, aggregate check
│   ├── data_model_validator.py    # 9 standard fields, non-persistable check
│   ├── synthesis_validator.py     # design narrative, trade-off decisions
│   └── final_doc_validator.py     # 9-chapter completeness, appendices
├── tools/
│   ├── llm.py             # LLM adapter (Hermes CLI / OpenAI / Anthropic)
│   ├── doc_parser.py      # .docx / .md parsing
│   ├── mermaid.py         # Kroki external render (opt-in via ALLOW_EXTERNAL_RENDER=1)
│   └── fallback.py        # Tool degradation strategies
├── prompts/  → symlink to ../agents/
└── schemas/  → symlink to ../schemas/
```

## Directory Structure Note

The skill uses directories beyond the standard `references/`, `templates/`, `scripts/`, `assets/` that `skill_manage write_file` supports:

- `agents/` — Stage prompt templates (7 files)
- `schemas/` — Output validation schemas (5 files)
- `harness/` — Harness engineering constraints (2 files)
- `orchestrator/` — Orchestration rules (3 files)
- `engine/` — Python engine (15+ files)

These were written directly to `~/.hermes/skills/design-workflow/` via `terminal` + `execute_code` since `skill_manage write_file` enforces the standard directory whitelist. The SKILL.md references them with relative paths and the engine's `prompts/` and `schemas/` symlink back to `agents/` and `schemas/`.

## Key Design Decisions

1. **LLM adapter defaults to Hermes CLI** (`hermes chat -q ...`). Fallback to OpenAI/Anthropic via env vars.
2. **External Mermaid rendering is OFF by default**. Set `ALLOW_EXTERNAL_RENDER=1` to enable Kroki.
3. **Feishu publishing is OFF by default**. Set `DWE_FEISHU_PUBLISH=1` to enable.
4. **State is persisted as JSON** under `outputs/runs/{run_id}/state.json` for resume capability.
5. **Maturity gate**: STAGE_2 score < 50 pauses execution (auto mode warns, review mode annotates).
