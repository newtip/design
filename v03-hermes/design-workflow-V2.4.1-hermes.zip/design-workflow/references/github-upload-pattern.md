# GitHub API Upload Pattern (no `gh` CLI)

Use when `gh` CLI is unavailable. Requires a Personal Access Token with repo scope.

## Single-Commit Multi-File Upload

```python
import urllib.request, json, os, base64

TOKEN = 'ghp_xxx'
REPO = 'owner/repo'
BRANCH = 'main'
FOLDER = 'target-folder/'
output_dir = '/path/to/files'

def github_api(method, path, data=None):
    url = f'https://api.github.com/repos/{REPO}{path}'
    headers = {
        'Authorization': f'Bearer {TOKEN}',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
    }
    if data:
        req = urllib.request.Request(url, data=json.dumps(data).encode(),
                                      headers=headers, method=method)
    else:
        req = urllib.request.Request(url, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())

# Step 1: Get base commit SHA
branch_info = github_api('GET', f'/git/ref/heads/{BRANCH}')
base_sha = branch_info['object']['sha']

# Step 2: Get base tree SHA
commit_info = github_api('GET', f'/git/commits/{base_sha}')
base_tree_sha = commit_info['tree']['sha']

# Step 3: Create blobs for each file
blobs = {}
for fn in sorted(os.listdir(output_dir)):
    with open(os.path.join(output_dir, fn), 'rb') as f:
        content = f.read()
    result = github_api('POST', '/git/blobs', {
        'content': base64.b64encode(content).decode(),
        'encoding': 'base64',
    })
    blobs[fn] = result['sha']

# Step 4: Create tree
tree_items = [{'path': f'{FOLDER}{fn}', 'mode': '100644',
               'type': 'blob', 'sha': sha}
              for fn, sha in blobs.items()]
tree_result = github_api('POST', '/git/trees', {
    'base_tree': base_tree_sha, 'tree': tree_items,
})

# Step 5: Create commit
commit_result = github_api('POST', '/git/commits', {
    'message': 'commit message',
    'tree': tree_result['sha'],
    'parents': [base_sha],
})

# Step 6: Update branch ref
github_api('PATCH', f'/git/refs/heads/{BRANCH}', {
    'sha': commit_result['sha'], 'force': False,
})

print(f"https://github.com/{REPO}/tree/{BRANCH}/{FOLDER}")
```

## Key API Endpoints

| Step | Method | Endpoint |
|------|--------|----------|
| Blob | POST | `/repos/{owner}/{repo}/git/blobs` |
| Tree | POST | `/repos/{owner}/{repo}/git/trees` |
| Commit | POST | `/repos/{owner}/{repo}/git/commits` |
| Ref | PATCH | `/repos/{owner}/{repo}/git/refs/heads/{branch}` |

## Notes

- Token stored in memory: `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`
- Default repo: `newtip/design`
- File naming: `{project}-{type}-{author}.{ext}`, kebab-case only, no Chinese characters
- Multi-agent outputs go to `vXX-{author}/` subdirectories
