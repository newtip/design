# Engine Integration: Agent-Managed Execution Pattern

## Problem

The Python engine's `LLMStage` defaults to calling `hermes chat -q` as a subprocess. Inside a Hermes session, this creates recursive processes that may hang or timeout. The `agent` pipe mode (`_call_agent_pipe`) writes to `/tmp/dwe/{run_id}/llm-input.md` and polls for output — fragile in background processes.

## Solution: Agent-Managed Sequential Execution

Let the current Hermes Agent drive the state machine manually while the Python engine handles state management, dependency checking, and validation.

### Pattern

```python
import sys, os
sys.path.insert(0, os.path.expanduser('~/.hermes/skills/design-workflow/engine'))

from memory.store import load_state, save_state, create_initial_state
from memory.models import Stage, StageStatus
from workflow.graph import WorkflowGraph
from workflow.state_machine import is_blocking

state = create_initial_state('run-id', input_files=['doc.docx'], mode='auto')
graph = WorkflowGraph()

for tick in range(10):
    # 1. Refresh — promote PENDING/INVALIDATED stages to READY
    completed = {s.stage for s in state.stages.values() if s.status == StageStatus.COMPLETED}
    for stage in graph.priority_order:
        snap = state.stages[stage]
        if snap.status in {StageStatus.PENDING, StageStatus.INVALIDATED}:
            if graph.is_ready(stage, completed):
                snap.status = StageStatus.READY
    
    # 2. Find next READY stage
    next_stage = None
    for stage in graph.priority_order:
        if state.stages[stage].status == StageStatus.READY:
            next_stage = stage
            break
    
    if next_stage is None:
        break
    
    # 3. Mark RUNNING
    snap = state.stages[next_stage]
    snap.status = StageStatus.RUNNING
    
    # 4. Agent generates content
    snap.output = { ... agent-generated structured output ... }
    
    # 5. Set COMPLETED and save
    snap.status = StageStatus.COMPLETED
    save_state(state)
```

## Key Principles

1. **Agent = LLM, Engine = State Manager.** The agent is the content generator; the engine is the referee.
2. **One stage per tick.** Never batch multiple stages in one agent response. The engine's state machine only makes sense when stages execute sequentially.
3. **Save after each stage.** `state.json` records progress, enabling breakpoint resume.
4. **Use the state machine — don't bypass it.** The whole point of the Python engine is state-driven non-linear execution. Generating all stages in parallel defeats this.

## LLM → Validator Impedance Mismatch

### Problem

LLM stages return natural language (`raw_response`), but validators expect structured JSON keys (`bounded_contexts`, `aggregates`, etc.). This mismatch causes validators to either fail silently (old soft-pass) or block the pipeline.

### Solution: Degraded Pass + Structured Parsing

V2.4.1 implements a three-tier strategy:

```
LLM output
  ↓
_parse_structured() — JSON block → YAML block → bare JSON → full YAML
  ↓ success?
Yes → structured output + raw_response preserved
No  → retry once with explicit JSON instruction
       ↓ success?
       Yes → structured output with warning
       No  → raw_response fallback + DEGRADED warning
```

Validators check for `raw_response`-only output and return a **degraded warning** (not silent pass, not hard block):
```python
if 'raw_response' in output and len(output) <= 3:
    return ['DEGRADED: Structured output missing, raw_response only. Quality gate weakened.']
```

This preserves quality gate visibility while allowing the pipeline to continue when structured parsing fails.

## Common Pitfalls

### 1. Bypassing the engine (CRITICAL)

```python
# ❌ WRONG: Generate all stages in parallel via execute_code
# This defeats the state machine, dependency checking, and validation.
execute_code("stage1 output"); execute_code("stage2 output"); ...

# ✅ RIGHT: Use the engine's state machine, one stage per tick
state = orchestrator.run_once(state)  # One stage. Then next tick.
```

### 2. STAGE_0: python-docx needs lxml

`python-docx` requires `lxml` which may not be installed. **Do not `pip install` in Hermes sessions** (may timeout). Use the pure Python fallback in `references/docx-fallback-parser.md`.

### 3. STAGE_6: Empty chapters placeholder

V2.3 returned `{f'chapter_{i}': '' for i in range(1, 10)}` — all empty. V2.4.1's `Stage6Writer._parse_chapters()` splits raw_response by "第N章" markers. This is a best-effort heuristic; the LLM should ideally be prompted to output chapter-structured content.

### 4. Overview structure path mismatch

`stage_6_writer.py` originally referenced `engine/schemas/overview_structure.yaml` which didn't exist. V2.4.1 fixes this:
- `templates/overview_structure.md` — Markdown reference for humans
- `engine/schemas/overview_structure.yaml` — Valid YAML schema for validation

## Agent-Pipe Mode (File-Based LLM)

For standalone CLI use where the engine needs to call LLM:

```
engine writes: /tmp/dwe/{run_id}/llm-input.md + /tmp/dwe/{run_id}/llm-ready
agent monitors: /tmp/dwe/{run_id}/llm-ready
agent writes:   /tmp/dwe/{run_id}/llm-output.md
engine reads:   /tmp/dwe/{run_id}/llm-output.md → continues
```

Isolation by `run_id` prevents multi-run conflicts. Use `LLM_PROVIDER=agent` to enable this mode.

## When to Use CLI Instead

Use the standalone CLI (`python -m app.main start --input xx.docx`) when:
- Running from a cron job
- Running from a non-Hermes terminal
- The agent is NOT available to generate content

## When to Use Agent-Managed

Use agent-managed execution when:
- Inside a Hermes session
- The user wants to see intermediate results
- Interactive review mode is needed
- The user may want to modify requirements mid-flow (cascade invalidation)

## GitHub Upload Pattern

When the design-workflow output needs to be uploaded to GitHub:

```python
# Use GitHub REST API directly (gh CLI may not be available)
import urllib.request, json, base64

TOKEN = '<github_token>'  # From memory
REPO = 'newtip/design'    # From memory

# 1. Create blobs → 2. Create tree → 3. Create commit → 4. Update ref
# See agent05-result-hermes.md session for full example
```

File naming convention: `{project}-{type}-{author}.{ext}`, all English kebab-case, no Chinese characters. Upload to `vXX-{author}/` subdirectory.
