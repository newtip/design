# 飞书协作文档 API 操作方法

当需要将概设输出写入飞书文档时，`feishu_doc_read` / `feishu_drive_add_comment` 等内置工具可能不可用（报错 "Feishu client not available"）。改用 terminal + 飞书 Open API 直调：

## 读取文档内容

```python
# GET /open-apis/docx/v1/documents/{doc_token}/raw_content
# Authorization: Bearer {tenant_access_token}
```

## 读取文档 Block 结构

```python
# GET /open-apis/docx/v1/documents/{doc_token}/blocks?page_size=100
```

## 追加 Block 到文档

```python
# POST /open-apis/docx/v1/documents/{doc_token}/blocks/{doc_token}/children
# Body:
{
    "children": [
        {
            "block_type": 2,  # 2=text, 3=heading3
            "text": {
                "elements": [{"text_run": {"content": "文本内容"}}],
                "style": {}
            }
        }
    ],
    "index": -1  # -1 = append to end
}
```

## 获取 tenant_access_token

```python
# POST /open-apis/auth/v3/tenant_access_token/internal
# Body: {"app_id": "...", "app_secret": "..."}
```

## 注意事项

- tenant_access_token 由 app_id + app_secret 获取，有效期约 2 小时
- 文档的 doc_token 从飞书文档 URL 中提取：`https://xxx.feishu.cn/docx/{doc_token}`
- Block type 映射：2=文本, 3=标题, 4=无序列表, 12=..., 31=表格, 32=表格单元格
- 追加内容后文档即时更新，用户刷新即可看到
