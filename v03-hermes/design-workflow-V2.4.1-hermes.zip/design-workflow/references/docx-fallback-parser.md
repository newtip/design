# DOCX Fallback Parser — Pure Python (no lxml)

## Problem

`python-docx` depends on `lxml` which may not be installed on the server. Installing via `pip install lxml` can timeout in Hermes sessions due to network constraints.

## Solution: Pure Python ZIP + XML Parser

Word `.docx` files are ZIP archives containing XML. Parse directly without `python-docx`:

```python
import zipfile
import xml.etree.ElementTree as ET

docx_path = '/path/to/document.docx'
ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

z = zipfile.ZipFile(docx_path)
xml_content = z.read('word/document.xml')
root = ET.fromstring(xml_content)

# Extract paragraphs
paragraphs = []
for para in root.iter(f'{{{ns}}}p'):
    texts = []
    for t in para.iter(f'{{{ns}}}t'):
        if t.text:
            texts.append(t.text)
    if texts:
        paragraphs.append(''.join(texts))

text = '\n'.join(paragraphs)

# Extract tables
tables = []
for table in root.iter(f'{{{ns}}}tbl'):
    rows = []
    for row in table.iter(f'{{{ns}}}tr'):
        cells = []
        for cell in row.iter(f'{{{ns}}}tc'):
            cell_texts = []
            for t in cell.iter(f'{{{ns}}}t'):
                if t.text:
                    cell_texts.append(t.text)
            cells.append(''.join(cell_texts))
        if cells:
            rows.append(cells)
    if rows:
        tables.append(rows)
```

## Table → Markdown Rendering

```python
for ti, table in enumerate(tables):
    if not table or not table[0]:
        continue
    header = table[0]
    md = f'\n### Table {ti}\n'
    md += '| ' + ' | '.join(str(c).replace('|', '\\|') for c in header) + ' |\n'
    md += '|' + '|'.join(['---'] * len(header)) + '|\n'
    for row in table[1:]:
        padded = list(row) + [''] * (len(header) - len(row))
        md += '| ' + ' | '.join(str(c).replace('|', '\\|') for c in padded[:len(header)]) + ' |\n'
```

## Why Tables Matter

Enterprise requirement documents frequently encode critical structured data in Word tables:
- Role-permission matrices
- Field definitions (name, type, required, source)
- State machine transitions
- Form field lists with auto-fill rules
- Sub-table structures

Failing to extract table content → downstream stages lack complete requirement facts → DDD modeling and data modeling are built on incomplete inputs.

The engine's `Stage0Parser` (V2.4.1+) uses this approach and reports `tables_fully_extracted: true/false` in its output.
