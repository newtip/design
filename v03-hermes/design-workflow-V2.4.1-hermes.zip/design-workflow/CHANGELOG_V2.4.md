# CHANGELOG V2.4 — 驾驭工程闭环版

## 基于 GPT 评审的 6 项关键修复

### 1. 结构化 LLM 输出（评审问题一）
- ✅ `LLMStage.run()` 新增 `_parse_structured()` 自动解析 LLM 返回的 JSON/YAML
- ✅ 所有 6 个 LLM Stage 挂载 `output_schema`（从 `schemas/*.yaml` 加载）
- ✅ 三层解析策略：```json → 裸 JSON → YAML → raw_response 兜底

### 2. INVALIDATED 自动复归 READY（评审问题三）
- ✅ `Orchestrator.refresh_ready_stages()` 同时处理 PENDING + INVALIDATED
- ✅ 上游依赖满足后自动激活为 READY
- ✅ 支持选择性重跑（只重跑受影响的阶段）

### 3. Router 接入 Orchestrator（评审问题四）
- ✅ 校验失败时自动调用 `route_after_failure()` 找到上游修复点
- ✅ 将建议修复阶段记录到 `state.global_facts['suggested_repair_stage']`
- ✅ 自动失效下游阶段（级联失效）

### 4. 成熟度 < 50 → NEEDS_CLARIFICATION（评审问题五）
- ✅ `industry_validator` 不再把低分当验证错误
- ✅ `Stage2Industry.run()` 判断 `maturity_score < 50` 返回 `needs_clarification=True`
- ✅ 状态机准确：低成熟度 = 需人类决策，不是模型失败

### 5. STAGE_0 完整 Word 表格解析（评审问题六）
- ✅ `stage_0_parser.py` 重写：纯 Python zipfile+XML
- ✅ 遍历 `<w:tbl>` 提取表格行/列/单元格
- ✅ 渲染为 Markdown table 嵌入 `full_markdown`
- ✅ 输出 `tables_fully_extracted: true`

### 6. ArchitectureMemory Pydantic 模型（评审问题七）
- ✅ 新增 `ArchitectureMemory` + 5 个子模型
- ✅ `ArchitectureDecision` / `ArchitectureAssumption` / `ArchitectureConstraint` / `ArchitectureConflict` / `StageCheckpoint`
- ✅ 挂载到 `WorkflowState.architecture_memory`
- ✅ 引擎级持久化，不再只是文档概念

---

## V2.4 vs V2.3 对比

| 维度 | V2.3 | V2.4 |
|------|------|------|
| LLM→结构化输出 | ❌ raw_response only | ✅ JSON/YAML auto-parse |
| Validator 真实可过 | ❌ 必然失败 | ✅ schema-aligned |
| INVALIDATED 重跑 | ❌ 卡住不动 | ✅ 自动 READY |
| Router 接入 | ❌ 代码存在，未调用 | ✅ 失败时自动路由 |
| 成熟度处理 | ❌ 当 validation_error | ✅ needs_clarification |
| Word 表格 | ❌ 只统计，不提取 | ✅ 完整 Markdown table |
| ArchitectureMemory | ❌ 文档概念 | ✅ Pydantic + 持久化 |

---

## V2.3 (2026-06-01) — Harness Engineering 骨架版
- 五层 Harness 结构
- DAG 依赖图 + 状态机
- 7 阶段 + CLI
- 5 个 validator
- Mermaid/飞书 工具降级
