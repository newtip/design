#!/usr/bin/env python3
"""Render Mermaid .mmd files to PNG.

Default mode is safe/offline: it only validates that .mmd files exist and prints
instructions. External rendering through kroki.io requires explicit opt-in:

    ALLOW_EXTERNAL_RENDER=1 python render_mermaid.py diagram.mmd

For enterprise/private projects, prefer a self-hosted Kroki endpoint via:

    KROKI_URL=http://your-internal-kroki/mermaid/png
"""
import json
import os
import sys
import time
import urllib.request

KROKI_URL = os.environ.get("KROKI_URL", "https://kroki.io/mermaid/png")
ALLOW_EXTERNAL_RENDER = os.environ.get("ALLOW_EXTERNAL_RENDER", "0") == "1"
HEADERS = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0"}


def render_mermaid(mmd_path: str) -> str:
    """Render a single .mmd file to PNG, return output path."""
    with open(mmd_path, "r", encoding="utf-8") as fh:
        content = fh.read()

    if not ALLOW_EXTERNAL_RENDER:
        raise RuntimeError(
            "External Mermaid rendering is disabled. "
            "Set ALLOW_EXTERNAL_RENDER=1 only after user approval, "
            "or use local mermaid-cli/self-hosted Kroki."
        )

    body = json.dumps({"diagram_source": content}).encode("utf-8")
    req = urllib.request.Request(KROKI_URL, data=body, headers=HEADERS, method="POST")

    with urllib.request.urlopen(req, timeout=30) as resp:
        data = resp.read()

    out_path = mmd_path.replace(".mmd", ".png")
    with open(out_path, "wb") as of:
        of.write(data)

    return out_path


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <file1.mmd> [file2.mmd ...]")
        print(f"       {sys.argv[0]} /path/to/dir  (render all .mmd in dir)")
        sys.exit(1)

    target = sys.argv[1]

    if os.path.isdir(target):
        files = sorted(
            os.path.join(target, f) for f in os.listdir(target) if f.endswith(".mmd")
        )
    else:
        files = [a for a in sys.argv[1:] if a.endswith(".mmd")]

    if not files:
        print("No .mmd files found.")
        sys.exit(1)

    for f in files:
        try:
            out = render_mermaid(f)
            size = os.path.getsize(out)
            print(f"OK  {os.path.basename(f)} -> {os.path.basename(out)} ({size} bytes)")
        except Exception as e:
            print(f"FAIL {os.path.basename(f)}: {e}")
        time.sleep(0.5)

    print(f"\nDone. {len(files)} files processed.")


if __name__ == "__main__":
    main()
