#!/usr/bin/env bash
# Feishu Publish Script — 创建飞书文档并设置为全员可读
#
# Usage:
#   bash feishu_publish.sh <project_name> <markdown_file>
#
# This script uses the feishu_doc and feishu_drive tools through the OpenClaw API.
# Since direct API calls from bash aren't straightforward, this serves as a wrapper
# that the Orchestrator can call, which in turn uses the feishu_doc tool.

set -euo pipefail

PROJECT_NAME="${1:?Usage: $0 <project_name> <markdown_file>}"
MD_FILE="${2:?Usage: $0 <project_name> <markdown_file>}"

if [ ! -f "$MD_FILE" ]; then
  echo "ERROR: File not found: $MD_FILE"
  exit 1
fi

echo "📄 Project: $PROJECT_NAME"
echo "📁 Markdown: $MD_FILE"
echo "✅ Ready for Feishu publish."

# The actual Feishu doc creation is done by the Orchestrator using feishu_doc tool.
# This script provides the pre-flight check and path resolution.

# Step 1: Validate markdown file exists and is non-empty
MD_SIZE=$(wc -c < "$MD_FILE")
if [ "$MD_SIZE" -lt 100 ]; then
  echo "⚠️  Warning: Markdown file is very small (${MD_SIZE} bytes)"
fi

# Step 2: Output absolute path for Orchestrator to consume
echo "ABSOLUTE_PATH=$(realpath "$MD_FILE")"
echo "TITLE=${PROJECT_NAME}_概设文档"
echo "STATUS=ready"
