"""STAGE_6: Solution writer — produce AE 9-chapter design document."""

from typing import Any

from stages.base import LLMStage, StageResult
from memory.models import WorkflowState
from validators.final_doc_validator import validate_final_output


class Stage6Writer(LLMStage):
    name = "STAGE_6_SOLUTION_WRITER"
    output_schema = None  # Will be loaded from schema file
    prompt_file = "06-solution-writer.md"

    def __init__(self):
        super().__init__()
        self._load_output_schema()

    def _load_output_schema(self):
        """Load output schema from YAML file."""
        from pathlib import Path
        schema_path = Path(__file__).parent.parent / "schemas" / "overview_structure.yaml"
        if schema_path.exists():
            import yaml
            with open(schema_path) as f:
                self.output_schema = yaml.safe_load(f)

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        base_ctx = super().build_context(state)
        from memory.models import Stage
        for s in (Stage.STAGE_1, Stage.STAGE_3, Stage.STAGE_4, Stage.STAGE_5):
            snap = state.stages.get(s)
            if snap and snap.output:
                base_ctx[s.value] = snap.output
        base_ctx['open_questions'] = state.open_questions
        base_ctx['assumptions'] = state.assumptions
        return base_ctx

    def run(self, context: dict[str, Any]) -> StageResult:
        prompt = self._load_prompt()
        response = self._call_llm(
            system_prompt=prompt,
            user_message=f"Write the 9-chapter design document based on:\n\n{context}",
        )
        # Parse chapters from raw_response
        chapters = self._parse_chapters(response)
        return StageResult(output={
            'raw_response': response,
            'chapters': chapters,
            'appendix_a_events': self._extract_section(response, '附录A|Appendix A|事件清单'),
            'appendix_b_generation_log': self._extract_section(response, '附录B|Appendix B|生成记录'),
            'ddl_statements': self._extract_ddl(response),
        })
    
    def _parse_chapters(self, text: str) -> dict:
        """Split raw response into chapters 1-9."""
        import re
        chapters = {f'chapter_{i}': '' for i in range(1, 10)}
        
        # Find chapter boundaries: "第X章" or "## Chapter X" or "## 第X章"
        pattern = r'(?:第([1-9])章|##\s*(?:Chapter\s*)?([1-9]))'
        splits = re.split(pattern, text)
        
        # Simple heuristic: split by "第N章" markers
        for i in range(1, 10):
            markers = [
                f'第{i}章', f'## 第{i}章', f'### 第{i}章',
                f'## Chapter {i}', f'Chapter {i}',
            ]
            for marker in markers:
                if marker in text:
                    # Find start and end
                    start = text.find(marker)
                    if start >= 0:
                        # Find next chapter or end
                        end = len(text)
                        for j in range(i+1, 10):
                            for nm in [f'第{j}章', f'## 第{j}章', f'Chapter {j}']:
                                pos = text.find(nm, start + len(marker))
                                if pos > 0 and pos < end:
                                    end = pos
                        chapters[f'chapter_{i}'] = text[start:end].strip()
                        break
        
        # If structured parsing failed, use the entire text as chapter placeholder
        total_found = sum(1 for v in chapters.values() if len(v) > 200)
        if total_found < 3:
            # Fallback: put entire response in chapter_1 and mark others
            chapters['chapter_1'] = text[:10000]
            for i in range(2, 10):
                chapters[f'chapter_{i}'] = f'(Content embedded in chapter 1 — {len(text)} chars total)'
        
        return chapters
    
    def _extract_section(self, text: str, pattern: str) -> str:
        """Extract a named section from text."""
        import re
        m = re.search(f'({pattern})', text, re.IGNORECASE)
        if m:
            start = m.start()
            end = min(start + 3000, len(text))
            return text[start:end].strip()
        return ''
    
    def _extract_ddl(self, text: str) -> str:
        """Extract DDL statements from text."""
        import re
        m = re.search(r'```sql\s*\n(.*?)\n```', text, re.DOTALL)
        if m:
            return m.group(1)
        return ''

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        output = result.output or {}
        return validate_final_output(output, state)
