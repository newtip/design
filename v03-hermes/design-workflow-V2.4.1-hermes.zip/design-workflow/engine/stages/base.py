"""Abstract base class for all workflow stages."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from memory.models import WorkflowState


@dataclass
class StageResult:
    output: dict[str, Any] = field(default_factory=dict)
    needs_clarification: bool = False
    questions: list[str] = field(default_factory=list)
    validation_errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class BaseStage(ABC):
    """Every stage must define: build_context -> run -> validate."""

    name: str

    @abstractmethod
    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        """Extract minimal context needed for this stage from global state."""
        ...

    @abstractmethod
    def run(self, context: dict[str, Any]) -> StageResult:
        """Execute the stage. Calls LLM or local tools, returns structured result."""
        ...

    @abstractmethod
    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        """Quality gate. Return list of validation error messages (empty = pass)."""
        ...


class LLMStage(BaseStage):
    """Stage that delegates generation to an LLM via a prompt template."""

    prompt_file: str  # Path to the .md prompt template
    output_schema: dict | None = None

    def _load_prompt(self) -> str:
        """Load the prompt template."""
        from pathlib import Path
        engine_dir = Path(__file__).parent.parent
        prompt_path = engine_dir / 'prompts' / self.prompt_file
        if prompt_path.exists():
            return prompt_path.read_text(encoding='utf-8')
        return f"# {self.name}\n\nNo prompt template found at {prompt_path}"

    def _call_llm(self, system_prompt: str, user_message: str) -> str:
        """Call the LLM. Override this or configure via tools/llm.py."""
        try:
            from tools.llm import call_llm
            return call_llm(system_prompt, user_message)
        except ImportError:
            raise NotImplementedError(
                "LLM calling not configured. Set up tools/llm.py or override _call_llm."
            )

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        """Default: collect all upstream stage outputs."""
        from workflow.graph import WorkflowGraph
        graph = WorkflowGraph()
        upstream = graph.upstream(self.name)
        context = {
            'global_facts': state.global_facts,
            'ubiquitous_language': state.ubiquitous_language,
            'assumptions': state.assumptions,
            'open_questions': state.open_questions,
            'upstream_outputs': {
                s.value: state.stages[s].output
                for s in upstream
                if state.stages[s].output
            },
        }
        return context

    def run(self, context: dict[str, Any]) -> StageResult:
        """Load prompt, call LLM, parse structured output matching schema.

        Strategy:
        1. Call LLM with schema-aware prompt
        2. Parse response as JSON/YAML (auto-detect)
        3. If parsing succeeds, return structured output
        4. If parsing fails, retry once with explicit JSON instruction
        5. Final fallback: return raw_response with DEGRADED warning
        """
        prompt = self._load_prompt()
        user_message = f"Context:\n{context}\n\nComplete the stage as described in the prompt. Return ONLY valid JSON matching the required schema. No markdown wrapping, no explanations outside the JSON."
        response = self._call_llm(prompt, user_message)

        # Attempt structured parsing
        parsed = self._parse_structured(response)
        
        if parsed and len(parsed) > 1:  # More than just {'raw_response': ...}
            parsed['raw_response'] = response  # Preserve raw for traceability
            return StageResult(output=parsed, warnings=[])
        
        # Retry once with stronger JSON instruction
        retry_prompt = f"{prompt}\n\nIMPORTANT: Your previous response could not be parsed as valid JSON. Reply with ONLY a JSON object. Start with {{ and end with }}."
        response2 = self._call_llm(retry_prompt, user_message)
        parsed2 = self._parse_structured(response2)
        
        if parsed2 and len(parsed2) > 1:
            parsed2['raw_response'] = response2
            return StageResult(
                output=parsed2,
                warnings=['Structured output recovered on retry']
            )

        # Degraded fallback
        return StageResult(
            output={'raw_response': response},
            warnings=['DEGRADED: Could not parse structured output. Validator will flag this.']
        )

    def _parse_structured(self, response: str) -> dict:
        """Parse LLM response into structured dict.

        Tries in order:
        1. ```json ... ``` code block
        2. ```yaml ... ``` code block
        3. Bare JSON object { ... }
        4. Full response as YAML
        Returns empty dict on failure.
        """
        import re, json

        # 1. JSON code block
        m = re.search(r'```(?:json)\s*\n(.*?)\n```', response, re.DOTALL | re.IGNORECASE)
        if m:
            try:
                return json.loads(m.group(1))
            except json.JSONDecodeError:
                pass

        # 2. YAML code block → JSON
        m = re.search(r'```(?:yaml)\s*\n(.*?)\n```', response, re.DOTALL | re.IGNORECASE)
        if m:
            try:
                import yaml
                data = yaml.safe_load(m.group(1))
                if isinstance(data, dict):
                    return data
            except Exception:
                pass

        # 3. Bare JSON
        try:
            m = re.search(r'\{[\s\S]*\}', response)
            if m:
                return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass

        # 4. Full text as YAML
        try:
            import yaml
            data = yaml.safe_load(response)
            if isinstance(data, dict) and len(data) > 1:
                return data
        except Exception:
            pass

        return {}
