"""STAGE_0: Document parsing — extract full text from .docx/.md/.txt with full table extraction."""

import re
import zipfile
import xml.etree.ElementTree as ET
from typing import Any

from stages.base import BaseStage, StageResult
from memory.models import WorkflowState


class Stage0Parser(BaseStage):
    name = "STAGE_0_DOCUMENT_PARSE"

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        return {'input_files': state.input_files}

    def run(self, context: dict[str, Any]) -> StageResult:
        files = context.get('input_files', [])
        if not files:
            return StageResult(
                needs_clarification=True,
                questions=["No input files provided. Please specify document path."],
            )

        all_markdown = []
        file_info = []

        for filepath in files:
            try:
                if filepath.endswith('.docx'):
                    md_text, stats = self._parse_docx(filepath)
                elif filepath.endswith('.md') or filepath.endswith('.txt'):
                    md_text, stats = self._parse_text(filepath)
                else:
                    return StageResult(
                        validation_errors=[f"Unsupported file format: {filepath}"]
                    )
                all_markdown.append(md_text)
                file_info.append(stats)
            except FileNotFoundError:
                return StageResult(
                    validation_errors=[f"File not found: {filepath}"]
                )
            except Exception as e:
                return StageResult(
                    validation_errors=[f"Error parsing {filepath}: {e}"]
                )

        full_text = '\n\n'.join(all_markdown)
        total_chars = sum(info['char_count'] for info in file_info)
        truncation_warning = (
            "⚠️ Warning: Document may be truncated (>100K chars). "
            "Please verify completeness."
            if total_chars > 100000 else ""
        )

        return StageResult(
            output={
                'full_text': full_text,
                'full_markdown': full_text,
                'file_info': file_info,
                'total_chars': total_chars,
                'truncation_warning': truncation_warning,
            },
            warnings=[truncation_warning] if truncation_warning else [],
        )

    def _parse_docx(self, filepath: str) -> tuple[str, dict]:
        """Pure Python docx parser: zipfile + xml.etree (no lxml needed).
        Extracts paragraphs AND tables as Markdown tables for full fidelity.
        """
        z = zipfile.ZipFile(filepath)
        xml_content = z.read('word/document.xml')
        root = ET.fromstring(xml_content)

        ns = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

        # Extract paragraphs
        paragraphs = []
        for para in root.iter(f'{{{ns}}}p'):
            texts = []
            for t in para.iter(f'{{{ns}}}t'):
                if t.text:
                    texts.append(t.text)
            if texts:
                paragraphs.append(''.join(texts))

        text = '\n'.join(paragraphs)

        # Extract tables as Markdown
        tables = []
        table_md_parts = []
        for ti, table in enumerate(root.iter(f'{{{ns}}}tbl')):
            rows = []
            for row in table.iter(f'{{{ns}}}tr'):
                cells = []
                for cell in row.iter(f'{{{ns}}}tc'):
                    cell_texts = []
                    for t in cell.iter(f'{{{ns}}}t'):
                        if t.text:
                            cell_texts.append(t.text)
                    cells.append(''.join(cell_texts))
                if cells:
                    rows.append(cells)
            if rows:
                tables.append(rows)
                # Render as Markdown table
                table_md_parts.append(f'\n### Table {ti}\n')
                header = rows[0]
                table_md_parts.append('| ' + ' | '.join(str(c).replace('|', '\\|') for c in header) + ' |')
                table_md_parts.append('|' + '|'.join(['---'] * len(header)) + '|')
                for row in rows[1:]:
                    padded = list(row) + [''] * (len(header) - len(row))
                    table_md_parts.append('| ' + ' | '.join(str(c).replace('|', '\\|') for c in padded[:len(header)]) + ' |')
                table_md_parts.append('')

        # Combine text + tables
        full_markdown = text
        if tables:
            full_markdown += '\n\n---\n\n## Extracted Tables ({0} tables)\n'.format(len(tables))
            full_markdown += '\n'.join(table_md_parts)

        stats = {
            'file': filepath,
            'paragraphs': len(paragraphs),
            'tables': len(tables),
            'char_count': len(full_markdown),
            'tables_fully_extracted': True,
        }
        return full_markdown, stats

    def _parse_text(self, filepath: str) -> tuple[str, dict]:
        with open(filepath, 'r', encoding='utf-8') as f:
            text = f.read()
        lines = text.split('\n')
        stats = {
            'file': filepath,
            'lines': len(lines),
            'char_count': len(text),
        }
        return text, stats

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        errors = []
        if not result.output:
            errors.append("No output from document parser")
            return errors

        text = result.output.get('full_text', '')
        if not text or len(text.strip()) < 100:
            errors.append("Document appears empty or too short (<100 chars)")

        return errors
