"""STAGE_4: Data model — entities, ER relationships, DDL generation."""

from typing import Any

from stages.base import LLMStage, StageResult
from memory.models import WorkflowState
from validators.data_model_validator import validate_data_model_output


class Stage4DataModel(LLMStage):
    name = "STAGE_4_DATA_MODEL"
    output_schema = None  # Will be loaded from schema file
    prompt_file = "04-data-model.md"

    def __init__(self):
        super().__init__()
        self._load_output_schema()

    def _load_output_schema(self):
        """Load output schema from YAML file."""
        from pathlib import Path
        schema_path = Path(__file__).parent.parent / "schemas" / "data-model.schema.yaml"
        if schema_path.exists():
            import yaml
            with open(schema_path) as f:
                self.output_schema = yaml.safe_load(f)

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        base_ctx = super().build_context(state)
        from memory.models import Stage
        for s in (Stage.STAGE_1, Stage.STAGE_3):
            snap = state.stages.get(s)
            if snap and snap.output:
                base_ctx[s.value] = snap.output
        return base_ctx

    def run(self, context: dict[str, Any]) -> StageResult:
        prompt = self._load_prompt()
        response = self._call_llm(
            system_prompt=prompt,
            user_message=f"Design data model based on:\n\n{context}",
        )
        return StageResult(output={'raw_response': response})

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        output = result.output or {}
        return validate_data_model_output(output)
