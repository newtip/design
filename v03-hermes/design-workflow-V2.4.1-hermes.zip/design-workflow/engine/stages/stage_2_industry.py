"""STAGE_2: Industry insight — pattern matching, maturity assessment, anomaly detection."""

from typing import Any

from stages.base import LLMStage, StageResult
from memory.models import WorkflowState
from validators.industry_validator import validate_industry_output


class Stage2Industry(LLMStage):
    name = "STAGE_2_INDUSTRY_INSIGHT"
    output_schema = None  # Will be loaded from schema file
    prompt_file = "02-industry-insight.md"

    def __init__(self):
        super().__init__()
        self._load_output_schema()

    def _load_output_schema(self):
        """Load output schema from YAML file."""
        from pathlib import Path
        schema_path = Path(__file__).parent.parent / "schemas" / "industry-insight.schema.yaml"
        if schema_path.exists():
            import yaml
            with open(schema_path) as f:
                self.output_schema = yaml.safe_load(f)

    def build_context(self, state: WorkflowState) -> dict[str, Any]:
        base_ctx = super().build_context(state)
        # Add requirement output for maturity assessment
        from memory.models import Stage
        stage1_snap = state.stages.get(Stage.STAGE_1)
        if stage1_snap and stage1_snap.output:
            base_ctx['requirement_output'] = stage1_snap.output
        return base_ctx

    def run(self, context: dict[str, Any]) -> StageResult:
        prompt = self._load_prompt()
        req_output = context.get('requirement_output', {})
        response = self._call_llm(
            system_prompt=prompt,
            user_message=f"Analyze the following requirement output for industry patterns and maturity:\n\n{req_output}",
        )
        # Check maturity score and trigger needs_clarification if < 50
        output = {'raw_response': response}
        import re, json
        maturity_score = 100  # Default: assume high maturity
        try:
            m = re.search(r'maturity_assessment[:\s]*\{[^}]*score[:\s]*(\d+)', response, re.IGNORECASE)
            if m:
                maturity_score = int(m.group(1))
        except Exception:
            pass
        
        if maturity_score < 50:
            return StageResult(
                output=output,
                needs_clarification=True,
                questions=[
                    f"Maturity score is {maturity_score}/100. The requirement document may be incomplete.",
                    "Please confirm: (1) Are there missing business scenarios? (2) Are exception flows defined?",
                    "Proceed with assumptions or pause to gather more requirements?"
                ],
                warnings=[f"Low maturity ({maturity_score}/100) — design will rely on significant assumptions."]
            )
        
        return StageResult(output=output)

    def validate(self, result: StageResult, state: WorkflowState) -> list[str]:
        output = result.output or {}
        return validate_industry_output(output)
