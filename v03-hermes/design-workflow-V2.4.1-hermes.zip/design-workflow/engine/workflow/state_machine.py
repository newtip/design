"""Stage lifecycle state machine with transition rules."""

from memory.models import StageStatus

ALLOWED_TRANSITIONS: dict[StageStatus, set[StageStatus]] = {
    StageStatus.PENDING: {
        StageStatus.READY,
        StageStatus.SKIPPED,
    },
    StageStatus.READY: {
        StageStatus.RUNNING,
    },
    StageStatus.RUNNING: {
        StageStatus.COMPLETED,
        StageStatus.NEEDS_CLARIFICATION,
        StageStatus.VALIDATION_FAILED,
        StageStatus.USER_REVIEW_REQUIRED,
    },
    StageStatus.NEEDS_CLARIFICATION: {
        StageStatus.READY,
        StageStatus.INVALIDATED,
    },
    StageStatus.VALIDATION_FAILED: {
        StageStatus.READY,
        StageStatus.INVALIDATED,
    },
    StageStatus.USER_REVIEW_REQUIRED: {
        StageStatus.COMPLETED,
        StageStatus.READY,
        StageStatus.INVALIDATED,
    },
    StageStatus.COMPLETED: {
        StageStatus.INVALIDATED,
    },
    StageStatus.INVALIDATED: {
        StageStatus.READY,
    },
    StageStatus.SKIPPED: {
        StageStatus.READY,
    },
}


def can_transition(source: StageStatus, target: StageStatus) -> bool:
    """Check if a status transition is allowed."""
    return target in ALLOWED_TRANSITIONS.get(source, set())


def is_terminal(status: StageStatus) -> bool:
    """Return True if the stage has reached a resting state."""
    return status in {
        StageStatus.COMPLETED,
        StageStatus.SKIPPED,
        StageStatus.NEEDS_CLARIFICATION,
        StageStatus.VALIDATION_FAILED,
        StageStatus.USER_REVIEW_REQUIRED,
    }


def is_blocking(status: StageStatus) -> bool:
    """Return True if this status blocks downstream execution."""
    return status in {
        StageStatus.NEEDS_CLARIFICATION,
        StageStatus.VALIDATION_FAILED,
        StageStatus.USER_REVIEW_REQUIRED,
    }
