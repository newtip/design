"""Router: decide where to go after a stage failure."""

from memory.models import Stage


def route_after_failure(stage: Stage, errors: list[str]) -> Stage | None:
    """Given a failed stage and its errors, suggest which upstream stage to fix.

    Returns None if the same stage should be retried.
    """
    error_text = ' '.join(errors).lower()

    if stage == Stage.STAGE_3:
        if any(kw in error_text for kw in ('no bounded context', 'no domain', 'missing context')):
            return Stage.STAGE_1
        if any(kw in error_text for kw in ('source_anchor', 'no requirement', 'unclear')):
            return Stage.STAGE_1
        if any(kw in error_text for kw in ('industry mismatch', 'pattern')):
            return Stage.STAGE_2

    if stage == Stage.STAGE_4:
        if any(kw in error_text for kw in ('business object', 'missing entity', 'no actor')):
            return Stage.STAGE_1
        if any(kw in error_text for kw in ('aggregate missing', 'no aggregate', 'missing aggregate', 'context mismatch')):
            return Stage.STAGE_3
        if any(kw in error_text for kw in ('standard field', 'data_id', 'del_flag')):
            return None  # Retry same stage — formatting issue

    if stage == Stage.STAGE_5:
        if any(kw in error_text for kw in ('no architecture', 'context gap')):
            return Stage.STAGE_3
        if any(kw in error_text for kw in ('data model', 'entity')):
            return Stage.STAGE_4
        if any(kw in error_text for kw in ('design narrative', 'unclear intent')):
            return Stage.STAGE_2

    if stage == Stage.STAGE_6:
        if any(kw in error_text for kw in ('missing chapter', 'empty chapter')):
            # Determine which stage to go back to based on which chapter is missing
            if any(kw in error_text for kw in ('chapter 1', 'chapter 2', 'chapter 3')):
                return Stage.STAGE_3
            if any(kw in error_text for kw in ('chapter 4',)):
                return Stage.STAGE_4
            if any(kw in error_text for kw in ('chapter 5',)):
                return Stage.STAGE_5
        if any(kw in error_text for kw in ('missing data model')):
            return Stage.STAGE_4
        if any(kw in error_text for kw in ('missing design narrative')):
            return Stage.STAGE_5

    # Default: retry same stage
    return None
