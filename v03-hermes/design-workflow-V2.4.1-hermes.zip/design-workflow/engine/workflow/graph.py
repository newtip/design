"""DAG-based stage dependency graph."""

from memory.models import Stage


class WorkflowGraph:
    """Defines stage dependencies and computes impact of changes."""

    dependencies: dict[Stage, set[Stage]] = {
        Stage.STAGE_0: set(),
        Stage.STAGE_1: {Stage.STAGE_0},
        Stage.STAGE_2: {Stage.STAGE_1},
        Stage.STAGE_3: {Stage.STAGE_1, Stage.STAGE_2},
        Stage.STAGE_4: {Stage.STAGE_1, Stage.STAGE_3},
        Stage.STAGE_5: {Stage.STAGE_2, Stage.STAGE_3, Stage.STAGE_4},
        Stage.STAGE_6: {Stage.STAGE_1, Stage.STAGE_3, Stage.STAGE_4, Stage.STAGE_5},
    }

    # Stage priority order for execution
    priority_order: list[Stage] = [
        Stage.STAGE_0,
        Stage.STAGE_1,
        Stage.STAGE_2,
        Stage.STAGE_3,
        Stage.STAGE_4,
        Stage.STAGE_5,
        Stage.STAGE_6,
    ]

    def upstream(self, stage: Stage) -> set[Stage]:
        """Return stages that must complete before this one."""
        return self.dependencies.get(stage, set())

    def downstream(self, stage: Stage) -> set[Stage]:
        """Return stages that depend on this one."""
        return {
            node for node, deps in self.dependencies.items()
            if stage in deps
        }

    def impacted_by_change(self, changed_stage: Stage) -> set[Stage]:
        """Recursively find all stages invalidated by a change."""
        impacted: set[Stage] = set()
        stack = [changed_stage]
        while stack:
            current = stack.pop()
            for child in self.downstream(current):
                if child not in impacted:
                    impacted.add(child)
                    stack.append(child)
        return impacted

    def is_ready(self, stage: Stage, completed: set[Stage]) -> bool:
        """Check if all upstream stages are completed."""
        return self.upstream(stage).issubset(completed)
