"""Pydantic models for workflow state persistence."""

from datetime import datetime, timezone
from typing import Any
from enum import Enum

from pydantic import BaseModel, Field


class Stage(str, Enum):
    STAGE_0 = "STAGE_0_DOCUMENT_PARSE"
    STAGE_1 = "STAGE_1_REQUIREMENT_REFINEMENT"
    STAGE_2 = "STAGE_2_INDUSTRY_INSIGHT"
    STAGE_3 = "STAGE_3_DDD_ARCHITECTURE"
    STAGE_4 = "STAGE_4_DATA_MODEL"
    STAGE_5 = "STAGE_5_DESIGN_SYNTHESIS"
    STAGE_6 = "STAGE_6_SOLUTION_WRITER"


class StageStatus(str, Enum):
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    NEEDS_CLARIFICATION = "needs_clarification"
    VALIDATION_FAILED = "validation_failed"
    USER_REVIEW_REQUIRED = "user_review_required"
    COMPLETED = "completed"
    INVALIDATED = "invalidated"
    SKIPPED = "skipped"


class StageSnapshot(BaseModel):
    stage: Stage
    status: StageStatus = StageStatus.PENDING
    output: dict[str, Any] | None = None
    validation_errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    clarification_questions: list[str] = Field(default_factory=list)
    user_confirmed: bool = False
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    version: int = 1



class ArchitectureDecision(BaseModel):
    decision_id: str
    decision: str
    stage: str
    confirmed_by: str = "system"
    rationale: str = ""


class ArchitectureAssumption(BaseModel):
    assumption_id: str
    assumption: str
    confidence: str = "medium"
    stage: str


class ArchitectureConstraint(BaseModel):
    constraint_id: str
    constraint: str
    origin: str = "design_decision"
    stage: str


class ArchitectureConflict(BaseModel):
    conflict_id: str
    description: str
    source_a: str
    source_b: str
    resolution: str | None = None


class StageCheckpoint(BaseModel):
    stage: str
    status: str
    completed_at: str | None = None
    notes: str = ""


class ArchitectureMemory(BaseModel):
    confirmed_decisions: list[ArchitectureDecision] = Field(default_factory=list)
    assumptions: list[ArchitectureAssumption] = Field(default_factory=list)
    constraints: list[ArchitectureConstraint] = Field(default_factory=list)
    conflicts: list[ArchitectureConflict] = Field(default_factory=list)
    stage_checkpoints: dict[str, StageCheckpoint] = Field(default_factory=dict)


class WorkflowState(BaseModel):
    run_id: str
    mode: str = "auto"  # "auto" | "review"
    input_files: list[str] = Field(default_factory=list)
    current_stage: Stage | None = None
    stages: dict[Stage, StageSnapshot] = Field(default_factory=dict)

    # Shared knowledge
    global_facts: dict[str, Any] = Field(default_factory=dict)
    ubiquitous_language: dict[str, str] = Field(default_factory=dict)
    assumptions: list[str] = Field(default_factory=list)
    open_questions: list[str] = Field(default_factory=list)

    # Architecture memory (engine-level persistence)
    architecture_memory: ArchitectureMemory = Field(default_factory=ArchitectureMemory)

    # Output tracking
    final_outputs: dict[str, str] = Field(default_factory=dict)

    class Config:
        use_enum_values = True
