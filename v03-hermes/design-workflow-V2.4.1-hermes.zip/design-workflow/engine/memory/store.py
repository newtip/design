"""Persist and load workflow state to/from JSON."""

from pathlib import Path
import json
import os

from memory.models import WorkflowState, Stage, StageSnapshot, StageStatus


def ensure_outputs_dir(run_id: str) -> Path:
    engine_dir = Path(os.path.expanduser('~/.hermes/skills/design-workflow/engine'))
    runs_dir = engine_dir / 'outputs' / 'runs' / run_id
    runs_dir.mkdir(parents=True, exist_ok=True)
    return runs_dir


def save_state(state: WorkflowState) -> Path:
    """Persist workflow state to outputs/runs/{run_id}/state.json."""
    runs_dir = ensure_outputs_dir(state.run_id)
    path = runs_dir / 'state.json'
    path.write_text(state.model_dump_json(indent=2), encoding='utf-8')
    return path


def load_state(run_id: str) -> WorkflowState | None:
    """Load workflow state from disk."""
    engine_dir = Path(os.path.expanduser('~/.hermes/skills/design-workflow/engine'))
    path = engine_dir / 'outputs' / 'runs' / run_id / 'state.json'
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding='utf-8'))
    # Reconstruct Stage keys (stored as strings in JSON)
    if 'stages' in data:
        data['stages'] = {
            Stage(k): StageSnapshot(**v)
            for k, v in data['stages'].items()
        }
    if 'current_stage' in data and data['current_stage']:
        data['current_stage'] = Stage(data['current_stage'])
    return WorkflowState(**data)


def create_initial_state(run_id: str, input_files: list[str] | None = None, mode: str = "auto") -> WorkflowState:
    """Create a fresh workflow state with all stages pending."""
    stages = {
        stage: StageSnapshot(stage=stage)
        for stage in Stage
    }
    return WorkflowState(
        run_id=run_id,
        mode=mode,
        input_files=input_files or [],
        stages=stages,
    )
