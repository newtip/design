"""Quality gate for STAGE_2 industry insight output."""

from validators.base import check_required_keys


def validate_industry_output(output: dict) -> list[str]:
    """Validate industry insight output has maturity score and actionable items."""
    errors = []

    required = ['industry_patterns', 'maturity_assessment', 'decision_todos', 'anomaly_scenarios']
    errors.extend(check_required_keys(output, required, 'industry'))

    # Check maturity assessment — low score is NOT a validation error,
    # it's a signal that the design needs human review (NEEDS_CLARIFICATION).
    # The orchestrator will handle this by checking for needs_clarification=True
    # in the StageResult, not by treating it as a validation_failure.
    maturity = output.get('maturity_assessment', {})
    if maturity:
        score = maturity.get('score', 0)
        if not isinstance(score, (int, float)) or not (0 <= score <= 100):
            errors.append(f"Maturity score must be 0-100, got: {score}")
        # NOTE: score < 50 is NOT added as a validation error.
        # Instead, STAGE_2.run() should return needs_clarification=True when score < 50.
        # This keeps the state machine accurate: low maturity = needs human input, not model failure.

    # Check decision todos are actionable
    for todo in output.get('decision_todos', []):
        if not todo.get('action') or not todo.get('owner'):
            errors.append(f"Decision todo missing action/owner: {todo.get('title', 'unnamed')}")

    return errors
