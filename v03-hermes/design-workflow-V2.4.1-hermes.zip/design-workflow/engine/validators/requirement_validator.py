"""Quality gate for STAGE_1 requirement output."""

from validators.base import check_required_keys, check_source_anchors


def validate_requirement_output(output: dict) -> list[str]:
    """Validate that requirement refinement output is complete and traceable."""
    errors = []

    # If this is a raw LLM response, do soft validation only
    if 'raw_response' in output and len(output) <= 3:
        return errors  # Soft-pass: accept raw LLM output

    # Check required top-level keys
    required = [
        'business_goals', 'actors', 'business_objects',
        'commands', 'events', 'business_rules',
        'fields', 'open_questions',
    ]
    errors.extend(check_required_keys(output, required, 'requirement'))

    # Check business goals have measurable outcomes
    for goal in output.get('business_goals', []):
        name = goal.get('name', 'unnamed')
        if not goal.get('measurable_outcome'):
            errors.append(f"Business goal '{name}' missing measurable_outcome")

    # Check actors
    for actor in output.get('actors', []):
        name = actor.get('name', 'unnamed')
        if not actor.get('role_type'):
            errors.append(f"Actor '{name}' missing role_type")

    # Check commands have source_anchor
    errors.extend(check_source_anchors(
        output.get('commands', []), 'Command'
    ))

    # Check business rules have source_anchor
    errors.extend(check_source_anchors(
        output.get('business_rules', []), 'Business rule'
    ))

    return errors
