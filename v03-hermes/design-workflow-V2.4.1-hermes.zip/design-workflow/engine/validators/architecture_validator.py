"""Quality gate for STAGE_3 DDD architecture output."""

from validators.base import check_required_keys


# Cross-cutting concern keywords that should NOT become bounded contexts
CROSS_CUTTING_KEYWORDS = ['日志', '权限', '通知', '缓存', '审计', 'log', 'auth', 'notify', 'cache', 'audit']


def validate_architecture_output(output: dict) -> list[str]:
    """Validate DDD architecture output for correctness and consistency."""
    errors = []

    # Degraded pass: structured output preferred but raw accepted with warning
    if 'raw_response' in output and len(output) <= 3:
        return ['DEGRADED: Structured output missing, raw_response only. Quality gate weakened.']

    required = ['bounded_contexts', 'aggregates', 'services', 'communication_patterns']
    errors.extend(check_required_keys(output, required, 'architecture'))

    # Check bounded contexts
    contexts = output.get('bounded_contexts', [])
    if not contexts:
        errors.append("No bounded contexts found. At least one context is required.")

    context_names = []
    for ctx in contexts:
        name = ctx.get('name', '')
        context_names.append(name)

        # Cross-cutting concern check
        if any(kw in name.lower() for kw in CROSS_CUTTING_KEYWORDS):
            errors.append(
                f"⛔ Suspicious bounded context: '{name}'. "
                f"Cross-cutting concerns should not be independent bounded contexts. "
                f"Consider distributing this capability across existing contexts."
            )

        if not ctx.get('ubiquitous_language'):
            errors.append(f"Bounded context '{name}' missing ubiquitous_language definition")

        if not ctx.get('responsibilities'):
            errors.append(f"Bounded context '{name}' has no responsibilities defined")

    # Check aggregates
    aggregates = output.get('aggregates', [])
    for agg in aggregates:
        name = agg.get('name', 'unnamed')
        if not agg.get('transaction_boundary'):
            errors.append(f"Aggregate '{name}' missing transaction_boundary")
        if not agg.get('root_entity'):
            errors.append(f"Aggregate '{name}' missing root_entity (aggregate root)")

        # Check aggregate belongs to a context
        ctx = agg.get('bounded_context', '')
        if ctx and ctx not in context_names:
            errors.append(f"Aggregate '{name}' references non-existent context: '{ctx}'")

    # Check services
    services = output.get('services', [])
    for svc in services:
        name = svc.get('name', 'unnamed')
        if not svc.get('type'):
            errors.append(f"Service '{name}' missing type (domain/application/infrastructure)")

    # Check policies describe business rules, not UI behavior
    policies = output.get('policies', [])
    ui_keywords = ['路由', '跳转', '导航', 'route', 'navigate', 'redirect', 'show', 'display']
    for pol in policies:
        name = pol.get('name', 'unnamed')
        desc = pol.get('description', '')
        if any(kw in desc.lower() for kw in ui_keywords):
            errors.append(
                f"⛔ Policy '{name}' describes UI behavior: '{desc[:80]}...'. "
                f"Policies must describe business rules, not UI/technical actions."
            )

    return errors
