"""Base validators and shared validation utilities."""

from typing import Any


def check_required_keys(output: dict, required: list[str], context: str = "") -> list[str]:
    """Check that all required keys exist in output."""
    errors = []
    for key in required:
        if key not in output:
            errors.append(f"[{context}] Missing required key: {key}")
    return errors


def check_source_anchors(items: list[dict], item_type: str) -> list[str]:
    """Verify every item has a source_anchor back to requirements."""
    errors = []
    for item in items:
        name = item.get('name', item.get('id', 'unnamed'))
        if not item.get('source_anchor'):
            errors.append(f"{item_type} '{name}' missing source_anchor")
    return errors
