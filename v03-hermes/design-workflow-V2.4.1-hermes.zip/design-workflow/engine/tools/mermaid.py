"""Mermaid diagram rendering. External render (e.g. Kroki) is OFF by default."""

import os
import subprocess
from pathlib import Path


def render_mermaid(mermaid_code: str, output_path: str | None = None) -> str:
    """Render Mermaid code to an image or return raw code block.

    External rendering (Kroki API) requires ALLOW_EXTERNAL_RENDER=1.
    """
    allow_external = os.getenv('ALLOW_EXTERNAL_RENDER', '0') == '1'

    if not allow_external:
        # Return as embedded code block
        return f"```mermaid\n{mermaid_code}\n```"

    # External render via Kroki
    import urllib.request
    import base64
    import zlib

    data = mermaid_code.encode('utf-8')
    compressed = base64.urlsafe_b64encode(zlib.compress(data)).decode('utf-8')
    url = f'https://kroki.io/mermaid/svg/{compressed}'

    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            svg_data = resp.read().decode('utf-8')
    except Exception as e:
        return f"```mermaid\n{mermaid_code}\n```\n\n<!-- Render failed: {e} -->"

    if output_path:
        Path(output_path).write_text(svg_data, encoding='utf-8')
        return f"![Mermaid Diagram]({output_path})"

    return svg_data


def generate_architecture_diagram(contexts: list[dict], output_path: str) -> str:
    """Generate a Mermaid C4-style architecture diagram from bounded contexts."""
    lines = ['graph TB']
    for i, ctx in enumerate(contexts):
        name = ctx.get('name', f'Context{i}')
        lines.append(f'    subgraph {name}')
        for svc in ctx.get('services', []):
            svc_name = svc.get('name', 'unnamed')
            lines.append(f'        {svc_name}[{svc_name}]')
        lines.append('    end')

    mermaid = '\n'.join(lines)
    return render_mermaid(mermaid, output_path)
