"""Document parsing utilities."""

import os


def parse_docx(filepath: str) -> dict:
    """Extract paragraphs and tables from .docx file."""
    try:
        from docx import Document
    except ImportError:
        return {'error': 'python-docx not installed. Run: pip install python-docx'}

    doc = Document(filepath)
    paragraphs = [p.text for p in doc.paragraphs]
    tables = []
    for table in doc.tables:
        rows = [[cell.text for cell in row.cells] for row in table.rows]
        tables.append(rows)

    return {
        'file': filepath,
        'paragraphs': paragraphs,
        'tables': tables,
        'paragraph_count': len(paragraphs),
        'table_count': len(tables),
        'total_chars': sum(len(p) for p in paragraphs),
    }


def parse_markdown(filepath: str) -> dict:
    """Read markdown file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()

    lines = text.split('\n')
    headings = [line for line in lines if line.startswith('#')]

    return {
        'file': filepath,
        'text': text,
        'lines': len(lines),
        'headings': headings,
        'char_count': len(text),
    }
