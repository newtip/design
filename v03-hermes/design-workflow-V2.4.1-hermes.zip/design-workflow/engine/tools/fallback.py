"""Tool fallback strategies — degrade gracefully when tools are missing."""

import sys


class ToolFallback:
    """Defines fallback behavior for optional tools."""

    @staticmethod
    def todo_fallback():
        """If todo tool is unavailable, use Markdown checklist."""
        return {
            'available': False,
            'strategy': 'markdown_checklist',
            'message': 'Using Markdown checklist for progress tracking.',
        }

    @staticmethod
    def clarify_fallback():
        """If clarify tool is unavailable, write questions to a file."""
        return {
            'available': False,
            'strategy': 'write_questions_file',
            'message': 'Writing clarification questions to outputs/clarifications.md',
        }

    @staticmethod
    def feishu_fallback():
        """If Feishu tools are unavailable, output locally only."""
        return {
            'available': False,
            'strategy': 'local_only',
            'message': 'Feishu publishing unavailable. Output saved to local files only.',
        }

    @staticmethod
    def mermaid_fallback():
        """If Mermaid rendering is unavailable, keep raw Mermaid code in output."""
        return {
            'available': False,
            'strategy': 'embed_raw_mermaid',
            'message': 'Mermaid rendering unavailable. Raw Mermaid code blocks embedded.',
        }


def is_tool_available(tool_name: str) -> bool:
    """Check if a specific tool is available in the current environment."""
    # Simple check: try importing the tool's module
    tool_modules = {
        'todo': 'hermes_tools.todo',
        'clarify': 'hermes_tools.clarify',
        'feishu_doc': 'hermes_tools.feishu_doc',
    }
    if tool_name in tool_modules:
        try:
            __import__(tool_modules[tool_name])
            return True
        except ImportError:
            return False
    return True  # Assume available by default
