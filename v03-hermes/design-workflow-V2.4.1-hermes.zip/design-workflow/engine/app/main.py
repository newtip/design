"""
Design Workflow Engine CLI.

Usage:
    python -m app.main start --input docs/requirement.docx
    python -m app.main status --run-id 20260601-001
    python -m app.main resume --run-id 20260601-001
    python -m app.main rerun --run-id 20260601-001 --stage STAGE_4
    python -m app.main export --run-id 20260601-001 --format markdown
"""

import argparse
import sys
import os
from datetime import datetime
from pathlib import Path

# Add engine dir to path
engine_dir = Path(__file__).parent.parent
sys.path.insert(0, str(engine_dir))

from workflow.graph import WorkflowGraph
from workflow.orchestrator import Orchestrator
from workflow.state_machine import StageStatus, is_blocking
from workflow.router import route_after_failure
from memory.models import WorkflowState, Stage, StageSnapshot
from memory.store import create_initial_state, save_state, load_state
from app.config import EngineConfig


def get_stage_implementations():
    """Lazy-load stage implementations."""
    from stages.stage_0_parser import Stage0Parser
    from stages.stage_1_requirement import Stage1Requirement
    from stages.stage_2_industry import Stage2Industry
    from stages.stage_3_architecture import Stage3Architecture
    from stages.stage_4_data_model import Stage4DataModel
    from stages.stage_5_synthesis import Stage5Synthesis
    from stages.stage_6_writer import Stage6Writer

    return {
        Stage.STAGE_0: Stage0Parser(),
        Stage.STAGE_1: Stage1Requirement(),
        Stage.STAGE_2: Stage2Industry(),
        Stage.STAGE_3: Stage3Architecture(),
        Stage.STAGE_4: Stage4DataModel(),
        Stage.STAGE_5: Stage5Synthesis(),
        Stage.STAGE_6: Stage6Writer(),
    }


def cmd_start(args):
    """Start a new workflow run."""
    run_id = args.run_id or datetime.now().strftime('%Y%m%d_%H%M%S')
    config = EngineConfig.from_env()

    state = create_initial_state(
        run_id=run_id,
        input_files=args.input,
        mode=config.mode if not args.review else 'review',
    )

    orchestrator = Orchestrator(
        graph=WorkflowGraph(),
        stages=get_stage_implementations(),
    )

    print(f"🚀 Starting design workflow: {run_id}")
    print(f"   Mode: {state.mode}")
    print(f"   Input: {state.input_files}")

    state = orchestrator.run_until_blocked(state)
    save_state(state)

    _print_status(state)
    _handle_blockers(state, orchestrator)


def cmd_status(args):
    """Show workflow status."""
    state = load_state(args.run_id)
    if state is None:
        print(f"❌ No run found: {args.run_id}")
        sys.exit(1)
    _print_status(state)


def cmd_resume(args):
    """Resume a paused workflow."""
    state = load_state(args.run_id)
    if state is None:
        print(f"❌ No run found: {args.run_id}")
        sys.exit(1)

    orchestrator = Orchestrator(
        graph=WorkflowGraph(),
        stages=get_stage_implementations(),
    )

    # Reset blocking stages to READY
    for snap in state.stages.values():
        if snap.status == StageStatus.NEEDS_CLARIFICATION:
            if snap.clarification_questions and not args.skip_clarify:
                print(f"⚠️  {snap.stage.value} still has pending questions:")
                for q in snap.clarification_questions:
                    print(f"   - {q}")
                should_continue = input("Proceed anyway? [y/N]: ").strip().lower()
                if should_continue != 'y':
                    return
            snap.status = StageStatus.READY
        elif snap.status == StageStatus.VALIDATION_FAILED:
            print(f"🔧 {snap.stage.value} had validation errors. Retrying...")
            snap.status = StageStatus.READY

    print(f"▶️  Resuming: {args.run_id}")
    state = orchestrator.run_until_blocked(state)
    save_state(state)
    _print_status(state)


def cmd_rerun(args):
    """Rerun a specific stage (invalidates downstream)."""
    state = load_state(args.run_id)
    if state is None:
        print(f"❌ No run found: {args.run_id}")
        sys.exit(1)

    stage = Stage(args.stage)
    orchestrator = Orchestrator(
        graph=WorkflowGraph(),
        stages=get_stage_implementations(),
    )

    print(f"🔄 Rerunning {stage.value} and invalidating downstream stages...")
    state = orchestrator.apply_change(state, stage, {})
    save_state(state)

    state = orchestrator.run_until_blocked(state)
    save_state(state)
    _print_status(state)


def cmd_export(args):
    """Export the final document."""
    state = load_state(args.run_id)
    if state is None:
        print(f"❌ No run found: {args.run_id}")
        sys.exit(1)

    writer_snap = state.stages.get(Stage.STAGE_6)
    if not writer_snap or writer_snap.status != StageStatus.COMPLETED:
        print(f"⚠️  STAGE_6 not completed (status: {writer_snap.status.value if writer_snap else 'N/A'})")
        print("   Run may need to be resumed first.")
        return

    # Save to output file
    output_text = writer_snap.output.get('raw_response', 'No output generated.')
    output_file = Path(engine_dir) / 'outputs' / 'runs' / args.run_id / 'final_design.md'
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(output_text, encoding='utf-8')

    print(f"📄 Exported to: {output_file}")
    print(f"   Size: {len(output_text)} characters")


def _print_status(state: WorkflowState):
    """Pretty-print workflow status."""
    print(f"\n{'='*60}")
    print(f"Run: {state.run_id} | Mode: {state.mode}")
    print(f"{'='*60}")
    print(f"{'Stage':<35} {'Status':<25} {'Errors':<8}")
    print(f"{'-'*68}")

    for stage in WorkflowGraph.priority_order:
        snap = state.stages[stage]
        status_icon = {
            StageStatus.PENDING: '⏳',
            StageStatus.READY: '▶️ ',
            StageStatus.RUNNING: '🔄',
            StageStatus.COMPLETED: '✅',
            StageStatus.NEEDS_CLARIFICATION: '❓',
            StageStatus.VALIDATION_FAILED: '❌',
            StageStatus.USER_REVIEW_REQUIRED: '👀',
            StageStatus.INVALIDATED: '♻️ ',
            StageStatus.SKIPPED: '⏭️ ',
        }.get(snap.status, '  ')
        n_errors = len(snap.validation_errors)
        print(f"{status_icon} {stage.value:<32} {snap.status.value:<25} {n_errors:<8}")
        if snap.validation_errors:
            for err in snap.validation_errors[:2]:
                print(f"   └─ {err[:80]}")

    # Summary
    completed = sum(1 for s in state.stages.values() if s.status == StageStatus.COMPLETED)
    total = len(state.stages)
    print(f"\nProgress: {completed}/{total} stages complete")
    if state.open_questions:
        print(f"Open questions: {len(state.open_questions)}")


def _handle_blockers(state: WorkflowState, orchestrator: Orchestrator):
    """Handle blocking conditions after a run."""
    for snap in state.stages.values():
        if snap.status == StageStatus.NEEDS_CLARIFICATION:
            print(f"\n❓ {snap.stage.value} needs clarification:")
            for q in snap.clarification_questions:
                print(f"   - {q}")
            print(f"\n   Resolve questions and resume with:")
            print(f"   python -m app.main resume --run-id {state.run_id}")
        elif snap.status == StageStatus.VALIDATION_FAILED:
            print(f"\n❌ {snap.stage.value} validation failed:")
            for err in snap.validation_errors:
                print(f"   - {err}")
            suggested_stage = route_after_failure(snap.stage, snap.validation_errors)
            if suggested_stage:
                print(f"\n   💡 Suggested fix: rerun {suggested_stage.value}, then retry.")
                print(f"   python -m app.main rerun --run-id {state.run_id} --stage {suggested_stage.value}")


def main():
    parser = argparse.ArgumentParser(
        description='Design Workflow Engine — DDD+AE 概设生成器 V2.3',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # start
    p_start = subparsers.add_parser('start', help='Start a new workflow run')
    p_start.add_argument('--input', '-i', nargs='+', required=True, help='Input document file(s)')
    p_start.add_argument('--run-id', help='Custom run ID (default: timestamp)')
    p_start.add_argument('--review', action='store_true', help='Use review mode (default: auto)')

    # status
    p_status = subparsers.add_parser('status', help='Show workflow status')
    p_status.add_argument('--run-id', '-r', required=True, help='Run ID')

    # resume
    p_resume = subparsers.add_parser('resume', help='Resume a paused workflow')
    p_resume.add_argument('--run-id', '-r', required=True, help='Run ID')
    p_resume.add_argument('--skip-clarify', action='store_true', help='Skip pending clarification questions')

    # rerun
    p_rerun = subparsers.add_parser('rerun', help='Rerun a specific stage')
    p_rerun.add_argument('--run-id', '-r', required=True, help='Run ID')
    p_rerun.add_argument('--stage', '-s', required=True, help='Stage to rerun (e.g., STAGE_3)')

    # export
    p_export = subparsers.add_parser('export', help='Export final document')
    p_export.add_argument('--run-id', '-r', required=True, help='Run ID')
    p_export.add_argument('--format', default='markdown', choices=['markdown', 'feishu'], help='Output format')

    args = parser.parse_args()

    if args.command == 'start':
        cmd_start(args)
    elif args.command == 'status':
        cmd_status(args)
    elif args.command == 'resume':
        cmd_resume(args)
    elif args.command == 'rerun':
        cmd_rerun(args)
    elif args.command == 'export':
        cmd_export(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
