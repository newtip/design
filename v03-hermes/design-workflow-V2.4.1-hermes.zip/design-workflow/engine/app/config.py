"""Global configuration for the design workflow engine."""

import os
import yaml
from pathlib import Path
from dataclasses import dataclass, field


@dataclass
class EngineConfig:
    # Execution
    mode: str = "auto"  # "auto" | "review"
    max_ticks: int = 10
    maturity_gate_threshold: int = 50  # Pause if maturity < 50

    # LLM
    llm_provider: str = "hermes"
    llm_model: str = "deepseek-v4-pro"

    # Output
    output_dir: str = str(Path.home() / '.hermes' / 'skills' / 'design-workflow' / 'engine' / 'outputs')
    output_format: str = "markdown"  # "markdown" | "feishu" | "both"

    # Validation
    strict_validation: bool = True
    require_source_anchors: bool = True

    # Features
    enable_mermaid: bool = False
    enable_feishu_publish: bool = False

    @classmethod
    def from_env(cls) -> 'EngineConfig':
        """Load config from environment variables."""
        return cls(
            mode=os.getenv('DWE_MODE', 'auto'),
            llm_provider=os.getenv('LLM_PROVIDER', 'hermes'),
            llm_model=os.getenv('LLM_MODEL', 'deepseek-v4-pro'),
            enable_mermaid=os.getenv('ALLOW_EXTERNAL_RENDER', '0') == '1',
            enable_feishu_publish=os.getenv('DWE_FEISHU_PUBLISH', '0') == '1',
        )

    @classmethod
    def from_file(cls, path: str) -> 'EngineConfig':
        """Load config from YAML file."""
        with open(path, 'r') as f:
            data = yaml.safe_load(f) or {}
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
