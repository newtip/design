# AE 9-Chapter Overview Design Structure Template

# 概设文档结构模板 — 用于 05-Solution Writer Agent 参考

## 章节排放顺序

```
第1章 功能清单
  1.1 项目概述
  1.2 功能模块总览
  1.3 角色分析
  1.4 痛点分析

第2章 系统架构设计
  2.1 架构总览
  2.2 分层架构说明
  2.3 服务划分
  2.4 技术栈
  2.5 系统整体结构图（Mermaid）

第3章 业务流程设计
  3.1 事件风暴概览
  3.2 业务能力地图
  3.3 核心业务流程
  3.4 领域关系（Context Map）

第4章 数据模型设计
  4.1 实体识别
  4.2 E-R 关系图（Mermaid）
  4.3 字段语义分类
  4.4 数据表结构（DDL）
  4.5 主数据识别（Optional）
  4.6 指标体系（Optional）

第5章 功能设计
  5.1 限界上下文功能框架
  5.2 核心功能详细设计

第6章 权限设计
  6.1 角色权限矩阵
  6.2 数据隔离方案

第7章 非功能设计
  7.1 性能设计
  7.2 安全设计
  7.3 可扩展性
  7.4 可靠性
  7.5 行业建议的非功能需求

第8章 遗留问题

第9章 工作量评估
```

## 各章数据来源映射

| 章节 | 数据来源 Agent | 关键字段 |
|:---:|------|------|
| Ch1 | 01-Req Refine | business_goal, capability_map, actors, pain_points |
| Ch2 | 03-DDD Arch | architecture_patterns, services |
| Ch3 | 01-Req + 03-DDD | event_storming, context_relationships, ubiquitous_language |
| Ch4 | 04-Data Model | entity_definitions, er_relationships, ddl |
| Ch5 | 01-Req + 03-DDD | contexts, structured_requirements.functions, aggregates[].entities[].business_behaviors |
| Ch6 | 01-Req + 03-DDD | actors, services.api_endpoints |
| Ch7 | 02-IIA + 03-DDD | industry_recommendations, architecture_patterns |
| Ch8 | 01-Req + 02-IIA | open_questions, design_decision_backlog |
| Ch9 | 03-DDD | contexts, services（按数量估算） |

## Mermaid 图表清单

| 图表 | 章节 | 类型 | 数据来源 |
|------|:---:|------|------|
| 系统整体结构图 | 2.5 | graph TB | architecture_design.services + contexts |
| Context Map | 3.4 | graph LR | architecture_design.context_relationships |
| 事件流图 | 3.3 | sequenceDiagram | business_model.event_storming.event_flows |
| E-R 图 | 4.2 | erDiagram | data_model.er_relationships |
| 服务依赖图 | 2.5 | graph LR | architecture_design.communication |

## 行业建议标注模板

```
✅ 已确认：<正常描述>

⚠️ 建议：<正常描述>（行业惯例，待确认）

🔶 默认假设：<作为设计前提的描述>（待审查）

❓ 待确认问题：已放入第8章遗留问题。
```
