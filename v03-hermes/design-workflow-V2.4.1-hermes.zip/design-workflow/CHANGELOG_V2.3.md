# CHANGELOG V2.3 — Harness Engineering 优化版

## 本次优化重点

1. 新增 `harness/HARNESS_ENGINEERING.md`：把 Skill 升级为可驾驭的工程化 Agent 流程。
2. 新增 `harness/TOOL_FALLBACKS.md`：定义 todo、clarify、terminal、飞书、Mermaid 等工具缺失时的降级策略。
3. 重写 `orchestrator/orchestrator.md`：从 6 阶段改为 STAGE_0~6 的 7 阶段编排器。
4. 重写 `orchestrator/smart_state_machine.md`：补齐 STAGE_0、成熟度门控、最终发布确认、外部渲染确认。
5. 修复 `orchestrator/architecture_memory.md`：补齐 STAGE_0 和 STAGE_6 checkpoint，增加可续跑状态字段。
6. 修复 `scripts/render_mermaid.py`：默认禁止外部 Kroki 渲染，必须 `ALLOW_EXTERNAL_RENDER=1` 显式开启；同时修复 usage f-string bug。
7. 修复 `schemas/data-model.schema.yaml`：统一字段语义枚举为 `ownership_field / foreign_reference / snapshot_field / projection_field / derived_field`。
8. 修正 `SKILL.md` 版本和概念：从 V2.0/V2.2 混杂统一到 V2.3，并加入五层 Harness 说明。

## 设计原则

- 人类掌舵，Agent 执行。
- 事实、建议、假设必须分层。
- 工具不可用时不失败，必须降级。
- 外部服务默认关闭，涉及发布/渲染必须用户确认。
- 每阶段必须有状态、门禁、回退和验收。
