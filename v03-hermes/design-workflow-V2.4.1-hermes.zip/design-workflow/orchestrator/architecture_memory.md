# Architecture Memory — 架构记忆模型

全流程共享的决策记录系统。防止 AI 漂移、保证设计一致性，并作为 Harness Engineering 的状态存储。

## 数据结构

```yaml
architecture_memory:
  project_name: ""
  mode: "auto|review"
  created_at: "<timestamp>"
  updated_at: "<timestamp>"

  # ─── 用户确认的设计决策（不可自动推翻）───
  confirmed_decisions:
  - decision_id: "DEC-001"
    decision: "<决策内容>"
    stage: "STAGE_3"
    confirmed_by: "user"
    timestamp: ""
    impact: ["<影响的上下文/聚合/服务>"]

  # ─── 系统推理得出的假设（标记置信度）───
  domain_assumptions:
  - assumption_id: "ASM-001"
    assumption: "<假设内容>"
    confidence: "high|medium|low"
    stage: "STAGE_1"
    verified_by: "stage|user|pending"

  # ─── 架构约束（全阶段有效，不可违反）───
  architecture_constraints:
  - constraint_id: "CST-001"
    constraint: "<约束内容>"
    origin: "ddd_rules|ae_rules|user_specified"
    stage: "init"

  # ─── 已确认的业务事实 ───
  business_facts:
  - fact_id: "FCT-001"
    fact: "<事实内容>"
    source: "business_model"
    stage: "STAGE_1"

  # ─── 设计取舍记录 ───
  design_tradeoffs:
  - tradeoff_id: "TRO-001"
    option_a: "<方案A>"
    option_b: "<方案B>"
    chosen: "A|B"
    reasoning: "<为什么选这个>"
    stage: "STAGE_3|STAGE_4"

  # ─── Stage 间数据流转状态 ───
  stage_checkpoints:
    STAGE_0:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "parsed_requirement_markdown"
      parse_completeness: "unknown|complete|partial|incomplete"
    STAGE_1:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "business_model"
      coverage_score: 0
    STAGE_2:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "industry_insight"
      maturity_score: 0
    STAGE_3:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "architecture_design"
      critical_conflicts: []
    STAGE_4:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "data_model"
      ddl_path: ""
    STAGE_5:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "design_synthesis"
    STAGE_6:
      completed: false
      output_validated: false
      user_confirmed: false
      artifact: "overview_markdown"
      local_markdown_path: ""
      feishu_url: ""
      final_acceptance_passed: false
```

## 强制引用规则

每个后续 Agent 在推理时必须：

1. **读取所有 confirmed_decisions** — 推理不得与之冲突
2. **读取所有 architecture_constraints** — 设计不得违反
3. **读取所有 business_facts** — 业务事实不可篡改
4. **标注引用** — 如果推理基于某个决策/约束/事实，标注 ID

```
反例（不引用）：
  决定：InventoryContext 采用最终一致性

正例（显式引用）：
  决定：InventoryContext 采用最终一致性
  引用：DEC-001（用户已在 STAGE_3 确认）
```

## 冲突检测

如果 Agent 的推理与 `confirmed_decisions` 冲突：
- 标记为 **CRITICAL** 错误
- 暂停流程
- 向用户说明冲突内容和影响范围
- 等待用户做出取舍

## 回退传播

如果用户推翻某个决策（如修改 Context 边界）：
1. 标记该决策为 `overridden`
2. 找到所有引用该决策的后续输出
3. 回退到受影响的第一阶段
4. 清除受影响的所有输出
5. 通知用户影响范围
