# Smart State Machine — 驾驭工程状态机（V2.3 — 7 阶段）

根据 `mode`、`maturity_score`、`gate_result` 和 `tool_availability` 控制 Agent 间的暂停/推进策略。

## 状态转换图（auto 模式）

```mermaid
stateDiagram-v2
    [*] --> STAGE_0_Execute : 接收需求文档
    STAGE_0_Execute --> STAGE_0_Validate : 00 完成
    STAGE_0_Validate --> STAGE_1_Execute : 解析完整或风险已标记
    STAGE_0_Validate --> STAGE_0_Retry : 解析失败
    STAGE_0_Retry --> STAGE_0_Execute

    STAGE_1_Execute --> STAGE_1_Validate : 01 完成
    STAGE_1_Validate --> STAGE_2_Execute : source_anchor 校验通过
    STAGE_1_Validate --> STAGE_1_Retry : 校验失败
    STAGE_1_Retry --> STAGE_1_Execute

    STAGE_2_Execute --> STAGE_2_Validate : 02 完成
    STAGE_2_Validate --> STAGE_3_Execute : maturity >= 50
    STAGE_2_Validate --> STAGE_2_Pause : maturity < 50
    STAGE_2_Validate --> STAGE_2_Retry : schema 失败
    STAGE_2_Retry --> STAGE_2_Execute

    STAGE_3_Execute --> STAGE_3_Validate : 03 完成
    STAGE_3_Validate --> STAGE_4_Execute : 架构门禁通过
    STAGE_3_Validate --> STAGE_3_Retry : 校验失败/记忆冲突
    STAGE_3_Retry --> STAGE_3_Execute

    STAGE_4_Execute --> STAGE_4_Validate : 04 完成
    STAGE_4_Validate --> STAGE_5_Execute : 数据门禁通过
    STAGE_4_Validate --> STAGE_4_Retry : 校验失败
    STAGE_4_Retry --> STAGE_4_Execute

    STAGE_5_Execute --> STAGE_5_Validate : 05 完成
    STAGE_5_Validate --> STAGE_6_Execute : 综合门禁通过
    STAGE_5_Validate --> STAGE_5_Retry : 校验失败
    STAGE_5_Retry --> STAGE_5_Execute

    STAGE_6_Execute --> STAGE_6_FinalReview : 06 完成
    STAGE_6_FinalReview --> LocalSave : 用户确认保存/导出
    STAGE_6_FinalReview --> Publish : 用户确认发布
    STAGE_6_FinalReview --> STAGE_6_Edit : 用户要求修改
    STAGE_6_Edit --> STAGE_6_Execute

    LocalSave --> [*]
    Publish --> [*]
```

## 状态转换图（review 模式）

```mermaid
stateDiagram-v2
    [*] --> STAGE_0_Execute
    STAGE_0_Execute --> STAGE_0_Validate
    STAGE_0_Validate --> STAGE_1_Execute

    STAGE_1_Execute --> STAGE_1_Review
    STAGE_1_Review --> STAGE_1_Edit : 用户修改
    STAGE_1_Edit --> STAGE_1_Execute
    STAGE_1_Review --> STAGE_2_Execute : 用户确认

    STAGE_2_Execute --> STAGE_2_Review
    STAGE_2_Review --> STAGE_2_Edit : 用户修改
    STAGE_2_Edit --> STAGE_2_Execute
    STAGE_2_Review --> STAGE_3_Execute : 用户确认

    STAGE_3_Execute --> STAGE_3_Review
    STAGE_3_Review --> STAGE_3_Edit : 用户修改
    STAGE_3_Edit --> STAGE_3_Execute
    STAGE_3_Review --> STAGE_4_Execute : 用户确认

    STAGE_4_Execute --> STAGE_4_Review
    STAGE_4_Review --> STAGE_4_Edit : 用户修改
    STAGE_4_Edit --> STAGE_4_Execute
    STAGE_4_Review --> STAGE_5_Execute : 用户确认

    STAGE_5_Execute --> STAGE_5_Review
    STAGE_5_Review --> STAGE_5_Edit : 用户修改
    STAGE_5_Edit --> STAGE_5_Execute
    STAGE_5_Review --> STAGE_6_Execute : 用户确认

    STAGE_6_Execute --> STAGE_6_FinalReview
    STAGE_6_FinalReview --> LocalSave : 用户确认保存/导出
    STAGE_6_FinalReview --> Publish : 用户确认发布
    STAGE_6_FinalReview --> STAGE_6_Edit : 用户要求修改
    STAGE_6_Edit --> STAGE_6_Execute

    LocalSave --> [*]
    Publish --> [*]
```

## 暂停策略矩阵

| Stage | Agent | Risk | auto | review | 强制暂停条件 |
|:---:|---|:---:|:---:|:---:|---|
| 0 | 00-Document Parser | MEDIUM | 自动 | 自动 | 文档无法解析/疑似严重截断 |
| 1 | 01-Req Refine | LOW | 自动 | 暂停 | source_anchor 缺失 |
| 2 | 02-Industry Insight | MEDIUM | 条件自动 | 暂停 | maturity_score < 50 |
| 3 | 03-DDD Architecture | HIGH | 自动 | 暂停 | 架构记忆冲突/横切误建 BC |
| 4 | 04-Data Model | MEDIUM | 自动 | 暂停 | DDL 与聚合归属冲突 |
| 5 | 05-Design Synthesis | MEDIUM | 自动 | 暂停 | 主线/工作台缺失 |
| 6 | 06-Solution Writer | FINAL | 暂停 | 暂停 | 发布/外部渲染前必须确认 |

## 回退规则

```yaml
rollback:
  STAGE_0:
    triggers: ["原始文档替换", "解析报告错误"]
    action: "清除 STAGE_0~6，重新解析"
  STAGE_1:
    triggers: ["用户修改需求文档", "需求理解有误", "source_anchor 缺失"]
    action: "清除 STAGE_1~6，重新提炼"
  STAGE_2:
    triggers: ["行业建议需修改", "成熟度重新评估"]
    action: "清除 STAGE_2~6，重新增强"
  STAGE_3:
    triggers: ["Context 边界调整", "聚合拆分修改", "架构记忆冲突"]
    action: "清除 STAGE_3~6，重新建模"
  STAGE_4:
    triggers: ["数据模型修改", "DDL 调整"]
    action: "清除 STAGE_4~6，重新建模"
  STAGE_5:
    triggers: ["设计综合修改", "产品结构调整"]
    action: "清除 STAGE_5~6，重新综合"
  STAGE_6:
    triggers: ["章节结构调整", "内容修改"]
    action: "重新执行 STAGE_6，不改变前序输出"
```

## 超时/中断处理

本状态机不依赖后台异步任务。若执行被中断，下一次续跑必须：

1. 读取 `architecture_memory.stage_checkpoints`。
2. 找到最后一个 `completed=true` 且 `output_validated=true` 的阶段。
3. 从下一个阶段继续。
4. 若缺少 checkpoint，则从最近可靠的用户确认点继续。
