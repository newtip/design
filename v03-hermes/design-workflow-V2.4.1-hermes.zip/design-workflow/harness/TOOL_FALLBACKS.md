# Tool Harness — 工具使用与降级策略

## 原则

工具是增强能力，不是流程前提。任何工具缺失时，Skill 必须降级到可交付状态。

## 工具兼容表

| 期望工具 | 用途 | 缺失时的降级策略 |
|---|---|---|
| todo | 跟踪阶段进度 | 使用 Markdown checklist |
| clarify | review 暂停确认 | 使用普通消息请求确认 |
| terminal | docx 解析、脚本执行 | 直接读取可用文本；无法解析时要求用户转 Markdown/文本 |
| session_search/search_files | 续跑定位历史输出 | 让用户粘贴已有阶段输出或从当前文件重新跑 |
| feishu_doc/feishu_drive | 创建飞书文档 | 输出本地 Markdown + 可复制全文 |
| Feishu Open API | 直连发布 | 仅当用户提供并授权 app_id/app_secret，且不得记录 secret |
| Kroki/mermaid-cli | Mermaid 渲染图片 | 默认只输出 Mermaid 源码；外部渲染需用户显式同意 |

## 外部服务安全开关

```yaml
external_services:
  mermaid_render:
    default: false
    require_user_opt_in: true
    recommended_private_backend: "self-hosted kroki or local mermaid-cli"
  feishu_publish:
    default: false
    require_user_confirmation: true
    secrets_policy: "never log or write secrets"
```
