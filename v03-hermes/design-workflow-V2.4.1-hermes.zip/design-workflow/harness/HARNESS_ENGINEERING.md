# Harness Engineering — 驾驭工程优化层（V2.4.1）

## 目标

把 Design Workflow 从“长 Prompt 顺序执行”升级为“可驾驭的工程化 Agent 系统”。核心思想：**人类掌舵，Agent 执行；模型负责生成，Harness 负责约束、状态、校验、回退和交付**。

## 五层驾驭结构

| 层 | 职责 | 在本 Skill 中的落点 |
|---|---|---|
| Goal Harness | 明确目标、范围、验收标准 | `SKILL.md` 的任务契约、9 章交付标准 |
| Context Harness | 控制输入上下文与事实来源 | STAGE_0 文档解析、source_anchor、architecture_memory |
| Process Harness | 控制阶段推进、暂停、回退 | `orchestrator/`、state machine、maturity gate |
| Tool Harness | 约束工具使用与降级策略 | terminal/feishu/mermaid fallback、外部渲染开关 |
| Quality Harness | 校验输出、风险、Traceability | schema lint、coverage matrix、final acceptance checklist |

## 全局执行契约

```yaml
harness_contract:
  version: "2.3"
  default_mode: "auto"
  human_control:
    - final_publish_requires_user_confirmation
    - maturity_below_50_requires_pause
    - external_render_requires_opt_in
  evidence_policy:
    requirement_facts: "must_have_source_anchor"
    industry_suggestions: "must_be_marked_as_recommendation_or_assumption"
    design_decisions: "must_have_reasoning_and_impact"
  state_policy:
    every_stage_writes_checkpoint: true
    every_decision_writes_architecture_memory: true
    rollback_clears_downstream_outputs: true
  tool_policy:
    missing_tool_must_fallback: true
    secrets_never_logged: true
    external_api_disabled_by_default: true
```

## 阶段准入/准出门禁

| Stage | Entry Gate | Exit Gate |
|---|---|---|
| STAGE_0 | 用户已提供文档或文本 | 解析报告完整，表格无截断或已标记风险 |
| STAGE_1 | STAGE_0 输出可用 | 业务事实、事件、功能、字段均有 source_anchor |
| STAGE_2 | business_model 可用 | 建议/风险/假设与已确认事实分离，maturity_score 已给出 |
| STAGE_3 | maturity >= 50 或用户确认继续 | Context、聚合、服务、关系均有推导理由 |
| STAGE_4 | 架构设计通过 | ER、字段语义、DDL 与聚合归属一致，投影字段不建列 |
| STAGE_5 | 数据模型通过 | 设计主线、工作台、产品结构、取舍明确 |
| STAGE_6 | 所有前序输出可追溯 | 9 章完整、遗留问题完整、发布前等待确认 |

## 失败恢复策略

| 失败类型 | 处理方式 |
|---|---|
| 文档解析不完整 | 停在 STAGE_0，输出缺失位置和补救建议 |
| Schema 校验失败 | 回到当前 Stage 修复，不推进下游 |
| 需求成熟度 < 50 | auto 强制暂停，列出必须确认的问题 |
| 架构记忆冲突 | 标记 CRITICAL，展示冲突决策和影响范围 |
| 飞书发布失败 | 保留本地 Markdown/SQL/Mermaid，报告失败原因 |
| 外部渲染未授权 | 不调用外部服务，仅输出 Mermaid 源码 |

## 驾驭工程反模式

- 只靠一个超长 Prompt 一次性生成全文。
- 中间阶段没有状态记录，后续章节忘记前面决策。
- 把行业经验写成已确认需求。
- 发现工具缺失后直接失败，而不是降级。
- 为了图像渲染把企业架构图默认发到外部服务。
- 最终发布不经用户确认。

## 最终验收 Checklist

```yaml
final_acceptance_checklist:
  traceability:
    - "每个核心功能至少有 1 个 source_anchor"
    - "每个核心事件至少绑定 1 个功能点"
    - "每个聚合至少说明事务边界"
  architecture:
    - "无横切关注点被误划为独立限界上下文"
    - "Context 关系模式清楚"
    - "统一语言贯穿章节"
  data_model:
    - "每张表包含企业级 9 标准字段"
    - "projection/derived 字段不进入 DDL"
    - "表名体现 Context 归属"
  delivery:
    - "9 章齐全"
    - "第8章列出所有待确认/假设/风险"
    - "第9章包含分阶段开发顺序与缓冲"
    - "发布前已获得用户确认"
```
