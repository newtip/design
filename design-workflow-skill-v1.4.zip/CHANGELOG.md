# design-workflow V1.4 变更说明

基于 OpenClaw V1.3 × Hermes V2.0 互评驱动优化

## 6项核心改进

1. 聚合粒度指引 — small-aggregates-first原则 + 4级拆分信号(S1-S4)，目标6-10聚合
2. 成熟度5维标准化 — business_completeness/data_certainty/process_clarity/role_clarity/integration_certainty
3. 异常场景枚举 — 第3章E1-E1n格式，覆盖边界/业务违规/异常流程/数据异常
4. 策略描述业务化 — 禁止UI/技术行为，领域专家可理解性检查
5. 表命名前缀规范 — Context前缀(tp_/enr_/appr_/exam_等)
6. 工作量分项拆分 — 每服务拆配置/开发/测试+15%缓冲

## 新增内容
- 第5种Mermaid图：序列图(sequenceDiagram)
- 02 Agent输出5维成熟度明细
- 03 Agent聚合拆分决策日志
- 06 Writer异常场景完整性检查+策略业务化校验
